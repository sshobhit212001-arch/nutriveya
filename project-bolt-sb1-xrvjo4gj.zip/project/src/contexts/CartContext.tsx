import { createContext, useContext, useEffect, useState, ReactNode, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './AuthContext';
import type { Product, CartItemWithProduct } from '../types/database';

interface CartContextType {
  items: CartItemWithProduct[];
  loading: boolean;
  itemCount: number;
  subtotal: number;
  addToCart: (product: Product, quantity?: number) => Promise<void>;
  updateQuantity: (productId: string, quantity: number) => Promise<void>;
  removeFromCart: (productId: string) => Promise<void>;
  clearCart: () => Promise<void>;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

const GUEST_CART_KEY = 'nutriveya_guest_cart';

interface GuestCartItem {
  product_id: string;
  quantity: number;
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItemWithProduct[]>([]);
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();

  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = items.reduce((sum, item) => {
    const price = item.product?.price ?? 0;
    return sum + price * item.quantity;
  }, 0);

  const fetchCart = useCallback(async () => {
    if (!user) {
      const guestCart = localStorage.getItem(GUEST_CART_KEY);
      if (guestCart) {
        try {
          const guestItems: GuestCartItem[] = JSON.parse(guestCart);
          if (guestItems.length > 0) {
            const { data: products } = await supabase
              .from('products')
              .select('*')
              .in('id', guestItems.map(i => i.product_id));

            const cartWithProducts: CartItemWithProduct[] = guestItems.map(item => {
              const product = products?.find(p => p.id === item.product_id);
              return {
                id: item.product_id,
                user_id: '',
                product_id: item.product_id,
                quantity: item.quantity,
                created_at: '',
                updated_at: '',
                product: product!,
              };
            }).filter(item => item.product);

            setItems(cartWithProducts);
          } else {
            setItems([]);
          }
        } catch {
          setItems([]);
        }
      } else {
        setItems([]);
      }
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('cart_items')
        .select('*, product:products(*)')
        .eq('user_id', user.id);

      if (!error && data) {
        setItems(data as CartItemWithProduct[]);
      }
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    fetchCart();
  }, [fetchCart]);

  const addToCart = async (product: Product, quantity = 1) => {
    if (!user) {
      const guestCart: GuestCartItem[] = JSON.parse(localStorage.getItem(GUEST_CART_KEY) || '[]');
      const existingItem = guestCart.find(i => i.product_id === product.id);

      if (existingItem) {
        existingItem.quantity += quantity;
      } else {
        guestCart.push({ product_id: product.id, quantity });
      }

      localStorage.setItem(GUEST_CART_KEY, JSON.stringify(guestCart));
      await fetchCart();
      return;
    }

    const existingItem = items.find(i => i.product_id === product.id);

    if (existingItem) {
      await updateQuantity(product.id, existingItem.quantity + quantity);
    } else {
      await supabase.from('cart_items').insert({
        user_id: user.id,
        product_id: product.id,
        quantity,
      });
      await fetchCart();
    }
  };

  const updateQuantity = async (productId: string, quantity: number) => {
    if (quantity < 1) {
      await removeFromCart(productId);
      return;
    }

    if (!user) {
      const guestCart: GuestCartItem[] = JSON.parse(localStorage.getItem(GUEST_CART_KEY) || '[]');
      const item = guestCart.find(i => i.product_id === productId);
      if (item) {
        item.quantity = quantity;
        localStorage.setItem(GUEST_CART_KEY, JSON.stringify(guestCart));
        await fetchCart();
      }
      return;
    }

    await supabase
      .from('cart_items')
      .update({ quantity })
      .eq('user_id', user.id)
      .eq('product_id', productId);
    await fetchCart();
  };

  const removeFromCart = async (productId: string) => {
    if (!user) {
      const guestCart: GuestCartItem[] = JSON.parse(localStorage.getItem(GUEST_CART_KEY) || '[]');
      const filtered = guestCart.filter(i => i.product_id !== productId);
      localStorage.setItem(GUEST_CART_KEY, JSON.stringify(filtered));
      await fetchCart();
      return;
    }

    await supabase
      .from('cart_items')
      .delete()
      .eq('user_id', user.id)
      .eq('product_id', productId);
    await fetchCart();
  };

  const clearCart = async () => {
    if (!user) {
      localStorage.removeItem(GUEST_CART_KEY);
      setItems([]);
      return;
    }

    await supabase.from('cart_items').delete().eq('user_id', user.id);
    setItems([]);
  };

  return (
    <CartContext.Provider value={{
      items,
      loading,
      itemCount,
      subtotal,
      addToCart,
      updateQuantity,
      removeFromCart,
      clearCart,
    }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
