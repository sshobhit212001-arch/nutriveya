import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  Heart,
  Minus,
  Plus,
  Share2,
  Star,
  Truck,
  Shield,
  RotateCcw,
  ChevronRight,
  Check,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import type { Product, Review, Category } from '../types/database';
import ProductCard from '../components/product/ProductCard';
import { Breadcrumb } from '../components/ui/Breadcrumb';
import { PageLoader } from '../components/ui/LoadingSpinner';

export default function ProductDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [category, setCategory] = useState<Category | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState('description');
  const [isZoomed, setIsZoomed] = useState(false);
  const { addToCart } = useCart();
  const { user } = useAuth();

  useEffect(() => {
    async function fetchProduct() {
      if (!slug) return;
      setLoading(true);
      try {
        const { data: productData, error } = await supabase
          .from('products')
          .select('*')
          .eq('slug', slug)
          .eq('is_active', true)
          .maybeSingle();

        if (error || !productData) {
          setLoading(false);
          return;
        }

        setProduct(productData);

        if (productData.category_id) {
          const { data: catData } = await supabase
            .from('categories')
            .select('*')
            .eq('id', productData.category_id)
            .maybeSingle();
          setCategory(catData);

          const { data: related } = await supabase
            .from('products')
            .select('*')
            .eq('category_id', productData.category_id)
            .neq('id', productData.id)
            .eq('is_active', true)
            .limit(4);
          setRelatedProducts(related || []);
        }

        const { data: reviewsData } = await supabase
          .from('reviews')
          .select('*')
          .eq('product_id', productData.id)
          .eq('is_approved', true)
          .order('created_at', { ascending: false });
        setReviews(reviewsData || []);
      } finally {
        setLoading(false);
      }
    }
    fetchProduct();
  }, [slug]);

  if (loading) return <PageLoader />;
  if (!product) {
    return (
      <div className="min-h-screen bg-cream flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-heading font-bold text-2xl text-gray-900 mb-4">Product Not Found</h1>
          <Link to="/shop" className="btn-primary">
            Back to Shop
          </Link>
        </div>
      </div>
    );
  }

  const images = product.images?.length > 0 ? product.images : [product.primary_image || 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=600'];
  const discount = product.compare_at_price
    ? Math.round(((product.compare_at_price - product.price) / product.compare_at_price) * 100)
    : 0;
  const avgRating = reviews.length > 0
    ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
    : '4.9';
  const inStock = product.stock_quantity > 0;
  const isLowStock = product.stock_quantity > 0 && product.stock_quantity <= product.low_stock_threshold;

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart(product);
    }
  };

  const tabs = [
    { id: 'description', label: 'Description' },
    { id: 'benefits', label: 'Benefits' },
    { id: 'nutrition', label: 'How to Use' },
    { id: 'reviews', label: `Reviews (${reviews.length || 24})` },
  ];

  return (
    <div className="min-h-screen bg-cream">
      <div className="container-custom py-8">
        <Breadcrumb
          items={[
            { label: 'Shop', href: '/shop' },
            category ? { label: category.name, href: `/category/${category.slug}` } : { label: 'Products', href: '/shop' },
            { label: product.name },
          ]}
        />

        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {/* Images */}
          <div className="space-y-4">
            <div className="relative aspect-square bg-white rounded-xl overflow-hidden">
              <img
                src={images[selectedImage]}
                alt={product.name}
                className={`w-full h-full object-cover transition-transform duration-300 cursor-zoom-in ${
                  isZoomed ? 'scale-150' : ''
                }`}
                onClick={() => setIsZoomed(!isZoomed)}
              />
              {discount > 0 && (
                <span className="absolute top-4 left-4 bg-red-500 text-white text-sm font-medium px-3 py-1 rounded">
                  -{discount}% OFF
                </span>
              )}
            </div>
            {images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-2">
                {images.map((img, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`w-20 h-20 rounded-lg overflow-hidden flex-shrink-0 border-2 transition-colors ${
                      selectedImage === index ? 'border-primary' : 'border-transparent'
                    }`}
                  >
                    <img src={img} alt={`${product.name} ${index + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Details */}
          <div className="space-y-6">
            <div>
              <span className="text-sm text-primary font-medium">
                {category?.name || 'Organic Superfood'}
              </span>
              <h1 className="font-heading font-bold text-3xl md:text-4xl text-gray-900 mt-1">
                {product.name}
              </h1>
              <div className="flex items-center gap-4 mt-3">
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-5 h-5 ${
                        i < Math.floor(parseFloat(avgRating))
                          ? 'fill-gold text-gold'
                          : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm text-gray-500">
                  {avgRating} ({reviews.length || 24} reviews)
                </span>
                {product.is_bestseller && (
                  <span className="text-xs bg-gold text-white px-2 py-1 rounded">Bestseller</span>
                )}
              </div>
            </div>

            <p className="text-gray-600">{product.short_description}</p>

            <div className="flex items-baseline gap-4">
              <span className="font-heading font-bold text-3xl text-primary">
                Rs {product.price.toFixed(0)}
              </span>
              {product.compare_at_price && (
                <>
                  <span className="text-xl text-gray-400 line-through">
                    Rs {product.compare_at_price.toFixed(0)}
                  </span>
                  <span className="text-sm text-green-600 font-medium">
                    Save Rs {(product.compare_at_price - product.price).toFixed(0)}
                  </span>
                </>
              )}
            </div>

            <div className="space-y-2 text-sm">
              {product.sku && (
                <p className="text-gray-500">
                  <span className="font-medium">SKU:</span> {product.sku}
                </p>
              )}
              <p className={`${inStock ? 'text-green-600' : 'text-red-500'}`}>
                <span className="font-medium">Availability:</span>{' '}
                {inStock ? (isLowStock ? `Only ${product.stock_quantity} left in stock` : 'In Stock') : 'Out of Stock'}
              </p>
              {product.weight && (
                <p className="text-gray-500">
                  <span className="font-medium">Weight:</span> {product.weight} {product.weight_unit}
                </p>
              )}
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center border rounded-lg">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="p-3 hover:bg-gray-100"
                  disabled={quantity <= 1}
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="px-4 py-3 font-medium">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="p-3 hover:bg-gray-100"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              <button
                onClick={handleAddToCart}
                disabled={!inStock}
                className="flex-1 btn-primary btn-lg"
              >
                Add to Cart
              </button>
              <button className="p-3 border rounded-lg hover:bg-gray-50">
                <Heart className="w-5 h-5" />
              </button>
              <button className="p-3 border rounded-lg hover:bg-gray-50">
                <Share2 className="w-5 h-5" />
              </button>
            </div>

            {product.is_new && (
              <Link
                to="/shop?sort=newest"
                className="inline-flex items-center gap-2 text-primary hover:underline"
              >
                Buy Now
                <ChevronRight className="w-4 h-4" />
              </Link>
            )}

            <div className="grid grid-cols-3 gap-4 pt-6 border-t">
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <Truck className="w-5 h-5 text-primary" />
                <div className="text-xs">
                  <p className="font-medium">Free Delivery</p>
                  <p className="text-gray-500">Orders above Rs 499</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <Shield className="w-5 h-5 text-primary" />
                <div className="text-xs">
                  <p className="font-medium">100% Authentic</p>
                  <p className="text-gray-500">Lab tested</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <RotateCcw className="w-5 h-5 text-primary" />
                <div className="text-xs">
                  <p className="font-medium">Easy Returns</p>
                  <p className="text-gray-500">7 day policy</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-xl p-6 md:p-8 mb-12">
          <div className="flex flex-wrap gap-2 md:gap-8 border-b mb-6">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`pb-3 font-medium transition-colors border-b-2 ${
                  activeTab === tab.id
                    ? 'text-primary border-primary'
                    : 'text-gray-500 border-transparent hover:text-gray-700'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="prose max-w-none">
            {activeTab === 'description' && (
              <div>
                <h3 className="font-heading font-semibold text-xl mb-4">Product Description</h3>
                <p className="text-gray-600 mb-4">{product.long_description || product.short_description}</p>
                {product.ingredients && (
                  <div className="mb-4">
                    <h4 className="font-medium text-gray-900 mb-2">Ingredients</h4>
                    <p className="text-gray-600">{product.ingredients}</p>
                  </div>
                )}
                {product.country_of_origin && (
                  <div className="mb-4">
                    <h4 className="font-medium text-gray-900 mb-2">Country of Origin</h4>
                    <p className="text-gray-600">{product.country_of_origin}</p>
                  </div>
                )}
                {product.shelf_life && (
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Shelf Life</h4>
                    <p className="text-gray-600">{product.shelf_life}</p>
                  </div>
                )}
              </div>
            )}
            {activeTab === 'benefits' && (
              <div>
                <h3 className="font-heading font-semibold text-xl mb-4">Benefits</h3>
                {product.benefits && product.benefits.length > 0 ? (
                  <ul className="space-y-3">
                    {product.benefits.map((benefit, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-primary mt-0.5" />
                        <span className="text-gray-600">{benefit}</span>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-gray-600">Supports overall health and wellness naturally.</p>
                )}
              </div>
            )}
            {activeTab === 'nutrition' && (
              <div>
                <h3 className="font-heading font-semibold text-xl mb-4">How to Use</h3>
                {product.directions && (
                  <div className="mb-4">
                    <h4 className="font-medium text-gray-900 mb-2">Directions</h4>
                    <p className="text-gray-600">{product.directions}</p>
                  </div>
                )}
                {product.storage_instructions && (
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Storage Instructions</h4>
                    <p className="text-gray-600">{product.storage_instructions}</p>
                  </div>
                )}
              </div>
            )}
            {activeTab === 'reviews' && (
              <div>
                <div className="flex items-center gap-8 mb-8">
                  <div className="text-center">
                    <p className="text-5xl font-heading font-bold text-gray-900">{avgRating}</p>
                    <div className="flex justify-center gap-1 mt-2">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-5 h-5 ${
                            i < Math.floor(parseFloat(avgRating)) ? 'fill-gold text-gold' : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                    <p className="text-sm text-gray-500 mt-1">{reviews.length || 24} reviews</p>
                  </div>
                </div>

                {reviews.length > 0 ? (
                  <div className="space-y-6">
                    {reviews.slice(0, 5).map((review) => (
                      <div key={review.id} className="border-b pb-6">
                        <div className="flex items-center gap-1 mb-2">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${i < review.rating ? 'fill-gold text-gold' : 'text-gray-300'}`}
                            />
                          ))}
                        </div>
                        {review.title && <h4 className="font-medium text-gray-900">{review.title}</h4>}
                        {review.content && <p className="text-gray-600 mt-2">{review.content}</p>}
                        <p className="text-sm text-gray-500 mt-2">
                          {new Date(review.created_at).toLocaleDateString('en-IN', {
                            day: 'numeric',
                            month: 'short',
                            year: 'numeric',
                          })}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-500">Be the first to review this product!</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div>
            <h2 className="font-heading font-bold text-2xl text-gray-900 mb-6">Related Products</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {relatedProducts.map((p) => (
                <ProductCard key={p.id} product={p} onAddToCart={() => addToCart(p)} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
