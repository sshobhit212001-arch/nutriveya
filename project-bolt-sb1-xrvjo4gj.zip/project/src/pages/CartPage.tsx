import { Link } from 'react-router-dom';
import { Trash2, Minus, Plus, ShoppingBag, ArrowRight } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import { Breadcrumb } from '../components/ui/Breadcrumb';

export default function CartPage() {
  const { items, loading, updateQuantity, removeFromCart, subtotal, itemCount } = useCart();
  const { user } = useAuth();

  const shippingCost = subtotal >= 499 ? 0 : 49;
  const total = subtotal + shippingCost;

  if (loading) {
    return (
      <div className="min-h-screen bg-cream flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cream">
      <div className="container-custom py-8">
        <Breadcrumb items={[{ label: 'Cart' }]} />

        <h1 className="font-heading font-bold text-3xl text-gray-900 mb-8">
          Shopping Cart
        </h1>

        {items.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-xl">
            <ShoppingBag className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h2 className="font-heading font-semibold text-xl text-gray-900 mb-2">
              Your cart is empty
            </h2>
            <p className="text-gray-500 mb-6">
              Looks like you haven't added anything to your cart yet.
            </p>
            <Link to="/shop" className="btn-primary">
              Continue Shopping
            </Link>
          </div>
        ) : (
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              <div className="bg-white rounded-xl p-4">
                <div className="flex items-center justify-between border-b pb-4 mb-4">
                  <span className="font-medium text-gray-900">
                    {itemCount} {itemCount === 1 ? 'Item' : 'Items'}
                  </span>
                  {user && (
                    <Link to="/wishlist" className="text-sm text-primary hover:underline">
                      View Wishlist
                    </Link>
                  )}
                </div>

                {items.map((item) => (
                  <div
                    key={item.id}
                    className="flex gap-4 py-4 border-b last:border-0"
                  >
                    <Link
                      to={`/product/${item.product?.slug}`}
                      className="w-24 h-24 flex-shrink-0"
                    >
                      <img
                        src={item.product?.primary_image || item.product?.images?.[0]}
                        alt={item.product?.name}
                        className="w-full h-full object-cover rounded-lg"
                      />
                    </Link>
                    <div className="flex-1 min-w-0">
                      <Link
                        to={`/product/${item.product?.slug}`}
                        className="font-heading font-semibold text-gray-900 hover:text-primary line-clamp-1"
                      >
                        {item.product?.name}
                      </Link>
                      {item.product?.weight && (
                        <p className="text-sm text-gray-500">
                          {item.product.weight} {item.product.weight_unit}
                        </p>
                      )}
                      <div className="flex items-center gap-4 mt-2">
                        <div className="flex items-center border rounded-lg">
                          <button
                            onClick={() => updateQuantity(item.product_id, item.quantity - 1)}
                            className="p-2 hover:bg-gray-100"
                          >
                            <Minus className="w-4 h-4" />
                          </button>
                          <span className="px-3 py-1 font-medium">{item.quantity}</span>
                          <button
                            onClick={() => updateQuantity(item.product_id, item.quantity + 1)}
                            className="p-2 hover:bg-gray-100"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        </div>
                        <button
                          onClick={() => removeFromCart(item.product_id)}
                          className="text-red-500 hover:text-red-600 p-2"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-heading font-bold text-primary">
                        Rs {((item.product?.price || 0) * item.quantity).toFixed(0)}
                      </p>
                      {item.product?.compare_at_price && (
                        <p className="text-sm text-gray-400 line-through">
                          Rs {((item.product.compare_at_price) * item.quantity).toFixed(0)}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-xl p-6 sticky top-24">
                <h2 className="font-heading font-semibold text-lg text-gray-900 mb-4">
                  Order Summary
                </h2>

                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Subtotal</span>
                    <span className="font-medium text-gray-900">Rs {subtotal.toFixed(0)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Shipping</span>
                    <span className={`font-medium ${shippingCost === 0 ? 'text-green-600' : 'text-gray-900'}`}>
                      {shippingCost === 0 ? 'FREE' : `Rs ${shippingCost}`}
                    </span>
                  </div>
                  {subtotal < 499 && (
                    <p className="text-xs text-gray-500 bg-primary-50 p-2 rounded">
                      Add Rs {(499 - subtotal).toFixed(0)} more for free shipping!
                    </p>
                  )}
                  <div className="border-t pt-3 flex justify-between">
                    <span className="font-medium text-gray-900">Total</span>
                    <span className="font-heading font-bold text-xl text-primary">
                      Rs {total.toFixed(0)}
                    </span>
                  </div>
                </div>

                <Link
                  to={user ? '/checkout' : '/login?redirect=/checkout'}
                  className="btn-primary w-full mt-6"
                >
                  Proceed to Checkout
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Link>

                <Link
                  to="/shop"
                  className="btn-secondary w-full mt-3"
                >
                  Continue Shopping
                </Link>

                <div className="mt-6 pt-6 border-t space-y-3">
                  <p className="text-xs text-gray-500 flex items-center gap-2">
                    <span className="w-4 h-4 bg-green-100 rounded-full flex items-center justify-center text-green-600 text-[10px]">✓</span>
                    100% Secure Payments
                  </p>
                  <p className="text-xs text-gray-500 flex items-center gap-2">
                    <span className="w-4 h-4 bg-green-100 rounded-full flex items-center justify-center text-green-600 text-[10px]">✓</span>
                    Free shipping on orders above Rs 499
                  </p>
                  <p className="text-xs text-gray-500 flex items-center gap-2">
                    <span className="w-4 h-4 bg-green-100 rounded-full flex items-center justify-center text-green-600 text-[10px]">✓</span>
                    Easy 7-day returns
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
