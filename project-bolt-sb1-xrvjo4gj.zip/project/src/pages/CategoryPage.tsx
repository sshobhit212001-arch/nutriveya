import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import type { Category, Product } from '../types/database';
import ProductCard from '../components/product/ProductCard';
import { Breadcrumb } from '../components/ui/Breadcrumb';
import { PageLoader } from '../components/ui/LoadingSpinner';
import { useCart } from '../contexts/CartContext';

export default function CategoryPage() {
  const { slug } = useParams<{ slug: string }>();
  const [category, setCategory] = useState<Category | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const { addToCart } = useCart();

  useEffect(() => {
    async function fetchData() {
      setLoading(true);
      const { data: categoriesData } = await supabase.from('categories').select('*').eq('is_active', true).order('display_order');
      setCategories(categoriesData || []);

      if (slug) {
        const cat = categoriesData?.find((c) => c.slug === slug);
        setCategory(cat || null);

        if (cat) {
          const { data: productsData } = await supabase
            .from('products')
            .select('*')
            .eq('category_id', cat.id)
            .eq('is_active', true);
          setProducts(productsData || []);
        }
      } else {
        setCategory(null);
        const { data: allProducts } = await supabase
          .from('products')
          .select('*')
          .eq('is_active', true);
        setProducts(allProducts || []);
      }
      setLoading(false);
    }
    fetchData();
  }, [slug]);

  if (loading) return <PageLoader />;

  return (
    <div className="min-h-screen bg-cream py-8">
      <div className="container-custom">
        <Breadcrumb items={[{ label: 'Categories', href: '/categories' }, ...(category ? [{ label: category.name }] : [])]} />

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <aside className="lg:w-64 flex-shrink-0">
            <div className="bg-white rounded-xl p-6 sticky top-24">
              <h2 className="font-heading font-semibold text-lg mb-4">Categories</h2>
              <ul className="space-y-2">
                <li>
                  <Link
                    to="/categories"
                    className={`block py-2 px-3 rounded-lg transition-colors ${
                      !category ? 'bg-primary text-white' : 'hover:bg-gray-100 text-gray-700'
                    }`}
                  >
                    All Products
                  </Link>
                </li>
                {categories.map((cat) => (
                  <li key={cat.id}>
                    <Link
                      to={`/category/${cat.slug}`}
                      className={`block py-2 px-3 rounded-lg transition-colors ${
                        category?.id === cat.id ? 'bg-primary text-white' : 'hover:bg-gray-100 text-gray-700'
                      }`}
                    >
                      {cat.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </aside>

          {/* Products */}
          <div className="flex-1">
            <div className="mb-6">
              <h1 className="font-heading font-bold text-3xl text-gray-900">
                {category?.name || 'All Products'}
              </h1>
              {category?.description && (
                <p className="text-gray-600 mt-2">{category.description}</p>
              )}
              <p className="text-gray-500 text-sm mt-2">{products.length} products</p>
            </div>

            {products.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-xl">
                <p className="text-gray-500">No products in this category.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                {products.map((product) => (
                  <ProductCard key={product.id} product={product} onAddToCart={() => addToCart(product)} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
