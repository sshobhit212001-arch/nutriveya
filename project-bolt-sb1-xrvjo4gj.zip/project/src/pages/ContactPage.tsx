import { useState } from 'react';
import { Mail, Phone, MapPin, Clock, Send, MessageCircle } from 'lucide-react';

const contactInfo = [
  {
    icon: Phone,
    title: 'Phone',
    details: ['+91 98765 43210', '+91 98765 43211'],
    action: 'tel:+919876543210',
  },
  {
    icon: Mail,
    title: 'Email',
    details: ['care@nutriveya.com', 'support@nutriveya.com'],
    action: 'mailto:care@nutriveya.com',
  },
  {
    icon: MapPin,
    title: 'Address',
    details: ['Nutriveya Wellness Pvt. Ltd.', 'Mumbai, Maharashtra', 'India - 400001'],
  },
  {
    icon: Clock,
    title: 'Business Hours',
    details: ['Monday - Saturday', '9:00 AM - 6:00 PM IST'],
  },
];

const faqs = [
  { q: 'How can I track my order?', a: 'You can track your order from the My Orders section in your account.' },
  { q: 'What is your return policy?', a: 'We offer 7-day easy returns on all unopened products.' },
  { q: 'Are your products organic?', a: 'Yes, all our products are 100% organic and certified.' },
];

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
    setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
  };

  return (
    <div className="min-h-screen bg-cream">
      {/* Hero */}
      <section className="bg-primary text-white py-12">
        <div className="container-custom text-center">
          <h1 className="font-heading font-bold text-4xl md:text-5xl mb-4">Contact Us</h1>
          <p className="text-primary-100 text-lg max-w-xl mx-auto">
            Have a question or need assistance? We're here to help you on your wellness journey.
          </p>
        </div>
      </section>

      <section className="py-12">
        <div className="container-custom">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div className="bg-white rounded-xl p-8 shadow-soft">
              <h2 className="font-heading font-semibold text-2xl text-gray-900 mb-6 flex items-center gap-2">
                <MessageCircle className="w-6 h-6 text-primary" />
                Send us a Message
              </h2>

              {submitted && (
                <div className="bg-green-50 text-green-600 p-4 rounded-lg mb-6">
                  Thank you for your message! We'll get back to you soon.
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="label">Full Name</label>
                    <input
                      type="text"
                      required
                      className="input"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Enter your name"
                    />
                  </div>
                  <div>
                    <label className="label">Email Address</label>
                    <input
                      type="email"
                      required
                      className="input"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="Enter your email"
                    />
                  </div>
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="label">Phone Number</label>
                    <input
                      type="tel"
                      className="input"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="Enter your phone"
                    />
                  </div>
                  <div>
                    <label className="label">Subject</label>
                    <select
                      className="input"
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    >
                      <option value="">Select a subject</option>
                      <option value="order">Order Inquiry</option>
                      <option value="product">Product Question</option>
                      <option value="wholesale">Wholesale Inquiry</option>
                      <option value="feedback">Feedback</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="label">Message</label>
                  <textarea
                    required
                    rows={5}
                    className="input"
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="How can we help you?"
                  />
                </div>
                <button type="submit" className="btn-primary w-full">
                  <Send className="w-4 h-4 mr-2" />
                  Send Message
                </button>
              </form>
            </div>

            {/* Contact Info */}
            <div className="space-y-6">
              {contactInfo.map((info) => (
                <div key={info.title} className="bg-white rounded-xl p-6 shadow-soft">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <info.icon className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-heading font-semibold text-gray-900 mb-2">{info.title}</h3>
                      {info.details.map((detail, i) => (
                        info.action ? (
                          <a
                            key={i}
                            href={info.action}
                            className="block text-gray-600 hover:text-primary transition-colors"
                          >
                            {detail}
                          </a>
                        ) : (
                          <p key={i} className="text-gray-600">{detail}</p>
                        )
                      ))}
                    </div>
                  </div>
                </div>
              ))}

              {/* Quick FAQs */}
              <div className="bg-white rounded-xl p-6 shadow-soft">
                <h3 className="font-heading font-semibold text-gray-900 mb-4">Quick Answers</h3>
                <div className="space-y-4">
                  {faqs.map((faq, i) => (
                    <div key={i} className="border-b pb-4 last:border-0 last:pb-0">
                      <p className="font-medium text-gray-900">{faq.q}</p>
                      <p className="text-sm text-gray-600 mt-1">{faq.a}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Map placeholder */}
      <section className="py-12 bg-white">
        <div className="container-custom">
          <div className="bg-gray-100 rounded-xl h-64 flex items-center justify-center">
            <p className="text-gray-500">Map Integration Coming Soon</p>
          </div>
        </div>
      </section>
    </div>
  );
}
