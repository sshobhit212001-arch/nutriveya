import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { CreditCard, Truck, MapPin, ChevronRight, Check, AlertCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { supabase } from '../lib/supabase';
import type { Address } from '../types/database';
import { PageLoader } from '../components/ui/LoadingSpinner';

const steps = ['Address', 'Payment', 'Review'];

const paymentMethods = [
  { id: 'razorpay', name: 'Razorpay', description: 'Pay via UPI, Cards, Netbanking' },
  { id: 'cod', name: 'Cash on Delivery', description: 'Pay when you receive' },
];

export default function CheckoutPage() {
  const { user, profile } = useAuth();
  const { items, subtotal, clearCart } = useCart();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [selectedAddress, setSelectedAddress] = useState<Address | null>(null);
  const [selectedPayment, setSelectedPayment] = useState('razorpay');
  const [formData, setFormData] = useState({
    full_name: profile?.full_name || '',
    phone: profile?.phone || '',
    address_line1: '',
    address_line2: '',
    city: '',
    state: '',
    postal_code: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const shippingCost = subtotal >= 499 ? 0 : 49;
  const total = subtotal + shippingCost;

  useEffect(() => {
    if (!user) {
      navigate('/login?redirect=/checkout');
      return;
    }
    if (items.length === 0) {
      navigate('/cart');
      return;
    }

    async function fetchAddresses() {
      const { data } = await supabase
        .from('addresses')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });
      setAddresses(data || []);
      if (data && data.length > 0) {
        setSelectedAddress(data[0]);
      }
    }
    fetchAddresses();
  }, [user, items, navigate]);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.full_name) newErrors.full_name = 'Name is required';
    if (!formData.phone) newErrors.phone = 'Phone is required';
    if (!formData.address_line1) newErrors.address_line1 = 'Address is required';
    if (!formData.city) newErrors.city = 'City is required';
    if (!formData.state) newErrors.state = 'State is required';
    if (!formData.postal_code) newErrors.postal_code = 'PIN code is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handlePlaceOrder = async () => {
    if (!user || !selectedAddress && !validateForm()) return;

    setLoading(true);
    try {
      const shippingAddress = selectedAddress ? {
        full_name: selectedAddress.full_name,
        phone: selectedAddress.phone,
        address_line1: selectedAddress.address_line1,
        address_line2: selectedAddress.address_line2,
        city: selectedAddress.city,
        state: selectedAddress.state,
        postal_code: selectedAddress.postal_code,
        country: selectedAddress.country,
      } : {
        full_name: formData.full_name,
        phone: formData.phone,
        address_line1: formData.address_line1,
        address_line2: formData.address_line2,
        city: formData.city,
        state: formData.state,
        postal_code: formData.postal_code,
        country: 'India',
      };

      const orderNumber = `NUT-${Date.now().toString(36).toUpperCase()}`;

      const { data: order, error: orderError } = await supabase
        .from('orders')
        .insert({
          user_id: user.id,
          order_number: orderNumber,
          subtotal,
          shipping_cost: shippingCost,
          total,
          shipping_address: shippingAddress,
          payment_method: selectedPayment,
          payment_status: selectedPayment === 'cod' ? 'pending' : 'pending',
          status: 'pending',
        })
        .select()
        .single();

      if (orderError) throw orderError;

      const orderItems = items.map((item) => ({
        order_id: order.id,
        product_id: item.product_id,
        product_name: item.product?.name || 'Product',
        product_sku: item.product?.sku,
        quantity: item.quantity,
        unit_price: item.product?.price || 0,
        total_price: (item.product?.price || 0) * item.quantity,
      }));

      const { error: itemsError } = await supabase
        .from('order_items')
        .insert(orderItems);

      if (itemsError) throw itemsError;

      await clearCart();

      navigate(`/order-success/${order.id}`);
    } catch (error) {
      console.error('Order error:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!user || items.length === 0) return <PageLoader />;

  return (
    <div className="min-h-screen bg-cream py-8">
      <div className="container-custom">
        {/* Steps */}
        <div className="flex items-center justify-center mb-8">
          {steps.map((step, index) => (
            <div key={step} className="flex items-center">
              <div
                className={`flex items-center gap-2 px-4 py-2 rounded-full ${
                  index <= currentStep
                    ? 'bg-primary text-white'
                    : 'bg-gray-200 text-gray-500'
                }`}
              >
                <span className="w-6 h-6 rounded-full border flex items-center justify-center text-sm font-medium">
                  {index < currentStep ? <Check className="w-4 h-4" /> : index + 1}
                </span>
                <span className="hidden sm:inline">{step}</span>
              </div>
              {index < steps.length - 1 && (
                <ChevronRight className="w-5 h-5 mx-2 text-gray-400" />
              )}
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Address Step */}
            {currentStep === 0 && (
              <div className="bg-white rounded-xl p-6">
                <h2 className="font-heading font-semibold text-xl mb-6 flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-primary" />
                  Delivery Address
                </h2>

                {addresses.length > 0 && (
                  <div className="mb-6">
                    <h3 className="font-medium text-gray-900 mb-3">Saved Addresses</h3>
                    <div className="grid gap-3">
                      {addresses.map((addr) => (
                        <label
                          key={addr.id}
                          className={`flex items-start gap-3 p-4 border rounded-lg cursor-pointer transition-colors ${
                            selectedAddress?.id === addr.id
                              ? 'border-primary bg-primary-50'
                              : 'border-gray-200 hover:border-gray-300'
                          }`}
                        >
                          <input
                            type="radio"
                            name="address"
                            checked={selectedAddress?.id === addr.id}
                            onChange={() => setSelectedAddress(addr)}
                            className="mt-1"
                          />
                          <div>
                            <p className="font-medium text-gray-900">{addr.full_name}</p>
                            <p className="text-sm text-gray-500">{addr.phone}</p>
                            <p className="text-sm text-gray-600">
                              {addr.address_line1}
                              {addr.address_line2 && `, ${addr.address_line2}`}
                              <br />
                              {addr.city}, {addr.state} - {addr.postal_code}
                            </p>
                          </div>
                        </label>
                      ))}
                    </div>
                  </div>
                )}

                <h3 className="font-medium text-gray-900 mb-4">Add New Address</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="label">Full Name</label>
                    <input
                      type="text"
                      className={`input ${errors.full_name ? 'input-error' : ''}`}
                      value={formData.full_name}
                      onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                    />
                    {errors.full_name && (
                      <p className="text-red-500 text-xs mt-1">{errors.full_name}</p>
                    )}
                  </div>
                  <div>
                    <label className="label">Phone Number</label>
                    <input
                      type="tel"
                      className={`input ${errors.phone ? 'input-error' : ''}`}
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    />
                    {errors.phone && (
                      <p className="text-red-500 text-xs mt-1">{errors.phone}</p>
                    )}
                  </div>
                  <div className="md:col-span-2">
                    <label className="label">Address Line 1</label>
                    <input
                      type="text"
                      className={`input ${errors.address_line1 ? 'input-error' : ''}`}
                      value={formData.address_line1}
                      onChange={(e) => setFormData({ ...formData, address_line1: e.target.value })}
                      placeholder="House/Flat No., Building"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="label">Address Line 2 (Optional)</label>
                    <input
                      type="text"
                      className="input"
                      value={formData.address_line2}
                      onChange={(e) => setFormData({ ...formData, address_line2: e.target.value })}
                      placeholder="Street, Area, Landmark"
                    />
                  </div>
                  <div>
                    <label className="label">City</label>
                    <input
                      type="text"
                      className={`input ${errors.city ? 'input-error' : ''}`}
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="label">State</label>
                    <input
                      type="text"
                      className={`input ${errors.state ? 'input-error' : ''}`}
                      value={formData.state}
                      onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="label">PIN Code</label>
                    <input
                      type="text"
                      className={`input ${errors.postal_code ? 'input-error' : ''}`}
                      value={formData.postal_code}
                      onChange={(e) => setFormData({ ...formData, postal_code: e.target.value })}
                    />
                  </div>
                </div>

                <button
                  onClick={() => {
                    if (selectedAddress || validateForm()) {
                      setCurrentStep(1);
                    }
                  }}
                  className="btn-primary w-full mt-6"
                >
                  Continue to Payment
                </button>
              </div>
            )}

            {/* Payment Step */}
            {currentStep === 1 && (
              <div className="bg-white rounded-xl p-6">
                <h2 className="font-heading font-semibold text-xl mb-6 flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-primary" />
                  Payment Method
                </h2>

                <div className="space-y-3">
                  {paymentMethods.map((method) => (
                    <label
                      key={method.id}
                      className={`flex items-center gap-4 p-4 border rounded-lg cursor-pointer transition-colors ${
                        selectedPayment === method.id
                          ? 'border-primary bg-primary-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <input
                        type="radio"
                        name="payment"
                        checked={selectedPayment === method.id}
                        onChange={() => setSelectedPayment(method.id)}
                        className="w-5 h-5"
                      />
                      <div>
                        <p className="font-medium text-gray-900">{method.name}</p>
                        <p className="text-sm text-gray-500">{method.description}</p>
                      </div>
                    </label>
                  ))}
                </div>

                <div className="flex gap-4 mt-6">
                  <button
                    onClick={() => setCurrentStep(0)}
                    className="btn-secondary flex-1"
                  >
                    Back
                  </button>
                  <button
                    onClick={() => setCurrentStep(2)}
                    className="btn-primary flex-1"
                  >
                    Review Order
                  </button>
                </div>
              </div>
            )}

            {/* Review Step */}
            {currentStep === 2 && (
              <div className="bg-white rounded-xl p-6">
                <h2 className="font-heading font-semibold text-xl mb-6">
                  Review Your Order
                </h2>

                <div className="space-y-4">
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <h3 className="font-medium text-sm text-gray-500 mb-2">Delivery Address</h3>
                    <p className="text-gray-900">
                      {selectedAddress?.full_name || formData.full_name}
                    </p>
                    <p className="text-sm text-gray-600">
                      {selectedAddress?.address_line1 || formData.address_line1}
                      {selectedAddress?.address_line2 || formData.address_line2},
                      <br />
                      {selectedAddress?.city || formData.city},{' '}
                      {selectedAddress?.state || formData.state} -{' '}
                      {selectedAddress?.postal_code || formData.postal_code}
                    </p>
                  </div>

                  <div className="p-4 bg-gray-50 rounded-lg">
                    <h3 className="font-medium text-sm text-gray-500 mb-2">Payment Method</h3>
                    <p className="text-gray-900">
                      {paymentMethods.find((m) => m.id === selectedPayment)?.name}
                    </p>
                  </div>

                  <div className="p-4 bg-gray-50 rounded-lg">
                    <h3 className="font-medium text-sm text-gray-500 mb-2">Order Items ({items.length})</h3>
                    {items.map((item) => (
                      <div key={item.id} className="flex items-center gap-3 py-2">
                        <img
                          src={item.product?.primary_image}
                          alt={item.product?.name}
                          className="w-12 h-12 object-cover rounded"
                        />
                        <div className="flex-1">
                          <p className="text-sm text-gray-900">{item.product?.name}</p>
                          <p className="text-xs text-gray-500">Qty: {item.quantity}</p>
                        </div>
                        <p className="font-medium">
                          Rs {((item.product?.price || 0) * item.quantity).toFixed(0)}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex gap-4 mt-6">
                  <button onClick={() => setCurrentStep(1)} className="btn-secondary flex-1">
                    Back
                  </button>
                  <button
                    onClick={handlePlaceOrder}
                    disabled={loading}
                    className="btn-primary flex-1"
                  >
                    {loading ? 'Placing Order...' : 'Place Order'}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl p-6 sticky top-24">
              <h2 className="font-heading font-semibold text-lg mb-4">Order Summary</h2>

              <div className="space-y-3 text-sm mb-6">
                {items.map((item) => (
                  <div key={item.id} className="flex items-center gap-3">
                    <img
                      src={item.product?.primary_image}
                      alt={item.product?.name}
                      className="w-12 h-12 object-cover rounded"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-gray-900 truncate">{item.product?.name}</p>
                      <p className="text-xs text-gray-500">Qty: {item.quantity}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="space-y-3 border-t pt-4">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Subtotal</span>
                  <span>Rs {subtotal.toFixed(0)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Shipping</span>
                  <span className={shippingCost === 0 ? 'text-green-600' : ''}>
                    {shippingCost === 0 ? 'FREE' : `Rs ${shippingCost}`}
                  </span>
                </div>
                <div className="flex justify-between font-heading font-bold text-lg border-t pt-3">
                  <span>Total</span>
                  <span className="text-primary">Rs {total.toFixed(0)}</span>
                </div>
              </div>

              <div className="mt-4 p-3 bg-green-50 rounded-lg flex items-start gap-2">
                <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-green-700">
                  Your order is eligible for free shipping on orders above Rs 499
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
