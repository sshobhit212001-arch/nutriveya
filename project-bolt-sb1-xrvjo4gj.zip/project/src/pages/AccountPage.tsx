import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { User, Package, Heart, MapPin, Settings, LogOut, ChevronRight, Edit, Trash2 } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import type { Order, Address, WishlistItemWithProduct } from '../types/database';
import ProductCard from '../components/product/ProductCard';
import { PageLoader } from '../components/ui/LoadingSpinner';
import { useCart } from '../contexts/CartContext';

const tabs = [
  { id: 'orders', name: 'My Orders', icon: Package },
  { id: 'wishlist', name: 'Wishlist', icon: Heart },
  { id: 'addresses', name: 'Addresses', icon: MapPin },
  { id: 'profile', name: 'Profile', icon: User },
];

export default function AccountPage() {
  const { user, profile, signOut, updateProfile } = useAuth();
  const { addToCart } = useCart();
  const [activeTab, setActiveTab] = useState('orders');
  const [orders, setOrders] = useState<Order[]>([]);
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [wishlist, setWishlist] = useState<WishlistItemWithProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingAddress, setEditingAddress] = useState<Address | null>(null);
  const [profileForm, setProfileForm] = useState({ full_name: '', phone: '' });

  useEffect(() => {
    if (!user) return;

    async function fetchData() {
      setLoading(true);
      try {
        const [ordersRes, addressesRes, wishlistRes] = await Promise.all([
          supabase.from('orders').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
          supabase.from('addresses').select('*').eq('user_id', user.id),
          supabase.from('wishlist_items').select('*, product:products(*)').eq('user_id', user.id),
        ]);

        setOrders(ordersRes.data || []);
        setAddresses(addressesRes.data || []);
        setWishlist(wishlistRes.data as WishlistItemWithProduct[] || []);

        if (profile) {
          setProfileForm({ full_name: profile.full_name || '', phone: profile.phone || '' });
        }
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, [user, profile]);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateProfile({ full_name: profileForm.full_name, phone: profileForm.phone });
  };

  const handleAddAddress = async (formData: Omit<Address, 'id' | 'user_id' | 'created_at'>) => {
    if (!user) return;

    const { data, error } = await supabase
      .from('addresses')
      .insert({ ...formData, user_id: user.id })
      .select();

    if (!error && data) {
      setAddresses([...addresses, ...data]);
    }
  };

  const handleDeleteAddress = async (id: string) => {
    const { error } = await supabase.from('addresses').delete().eq('id', id);
    if (!error) {
      setAddresses(addresses.filter((a) => a.id !== id));
    }
  };

  const handleRemoveFromWishlist = async (productId: string) => {
    if (!user) return;
    const { error } = await supabase
      .from('wishlist_items')
      .delete()
      .eq('user_id', user.id)
      .eq('product_id', productId);
    if (!error) {
      setWishlist(wishlist.filter((w) => w.product_id !== productId));
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-cream flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 mb-4">Please login to view your account</p>
          <Link to="/login" className="btn-primary">Login</Link>
        </div>
      </div>
    );
  }

  if (loading) return <PageLoader />;

  const statusColors: Record<string, string> = {
    pending: 'bg-yellow-100 text-yellow-800',
    processing: 'bg-blue-100 text-blue-800',
    shipped: 'bg-purple-100 text-purple-800',
    delivered: 'bg-green-100 text-green-800',
    cancelled: 'bg-red-100 text-red-800',
  };

  return (
    <div className="min-h-screen bg-cream py-8">
      <div className="container-custom">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="md:col-span-1">
            <div className="bg-white rounded-xl p-6">
              <div className="text-center mb-6">
                <div className="w-20 h-20 mx-auto bg-primary-100 rounded-full flex items-center justify-center mb-3">
                  <User className="w-10 h-10 text-primary" />
                </div>
                <h2 className="font-heading font-semibold text-gray-900">
                  {profile?.full_name || 'User'}
                </h2>
                <p className="text-sm text-gray-500">{profile?.email}</p>
              </div>

              <nav className="space-y-1">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                      activeTab === tab.id
                        ? 'bg-primary text-white'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <tab.icon className="w-5 h-5" />
                    {tab.name}
                  </button>
                ))}
                <button
                  onClick={signOut}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-red-600 hover:bg-red-50"
                >
                  <LogOut className="w-5 h-5" />
                  Sign Out
                </button>
              </nav>
            </div>
          </div>

          {/* Content */}
          <div className="md:col-span-3">
            {/* Orders */}
            {activeTab === 'orders' && (
              <div className="bg-white rounded-xl p-6">
                <h2 className="font-heading font-semibold text-xl mb-6">My Orders</h2>
                {orders.length === 0 ? (
                  <div className="text-center py-12">
                    <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500 mb-4">No orders yet</p>
                    <Link to="/shop" className="btn-primary">Start Shopping</Link>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {orders.map((order) => (
                      <div key={order.id} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div>
                            <p className="font-medium text-gray-900">{order.order_number}</p>
                            <p className="text-sm text-gray-500">
                              {new Date(order.created_at).toLocaleDateString('en-IN', {
                                day: 'numeric',
                                month: 'long',
                                year: 'numeric',
                              })}
                            </p>
                          </div>
                          <span className={`px-3 py-1 rounded-full text-sm ${statusColors[order.status]}`}>
                            {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <p className="text-gray-600">Total: Rs {order.total.toFixed(0)}</p>
                          <Link
                            to={`/order/${order.id}`}
                            className="text-primary text-sm hover:underline flex items-center gap-1"
                          >
                            View Details <ChevronRight className="w-4 h-4" />
                          </Link>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Wishlist */}
            {activeTab === 'wishlist' && (
              <div className="bg-white rounded-xl p-6">
                <h2 className="font-heading font-semibold text-xl mb-6">My Wishlist</h2>
                {wishlist.length === 0 ? (
                  <div className="text-center py-12">
                    <Heart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500 mb-4">Your wishlist is empty</p>
                    <Link to="/shop" className="btn-primary">Browse Products</Link>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {wishlist.map((item) => (
                      <div key={item.id} className="relative">
                        <ProductCard product={item.product} onAddToCart={() => addToCart(item.product)} />
                        <button
                          onClick={() => handleRemoveFromWishlist(item.product_id)}
                          className="absolute top-4 right-4 p-2 bg-white rounded-full shadow hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Addresses */}
            {activeTab === 'addresses' && (
              <div className="bg-white rounded-xl p-6">
                <h2 className="font-heading font-semibold text-xl mb-6">My Addresses</h2>
                <div className="grid md:grid-cols-2 gap-4 mb-6">
                  {addresses.map((addr) => (
                    <div key={addr.id} className="border rounded-lg p-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="font-medium text-gray-900">{addr.full_name}</p>
                          <p className="text-sm text-gray-500">{addr.phone}</p>
                          <p className="text-sm text-gray-600 mt-2">
                            {addr.address_line1}
                            {addr.address_line2 && `, ${addr.address_line2}`}
                            <br />
                            {addr.city}, {addr.state} - {addr.postal_code}
                          </p>
                          {addr.is_default && (
                            <span className="inline-block mt-2 text-xs bg-primary-100 text-primary px-2 py-1 rounded">
                              Default
                            </span>
                          )}
                        </div>
                        <div className="flex gap-2">
                          <button onClick={() => setEditingAddress(addr)} className="p-2 hover:bg-gray-100 rounded">
                            <Edit className="w-4 h-4 text-gray-500" />
                          </button>
                          <button onClick={() => handleDeleteAddress(addr.id)} className="p-2 hover:bg-red-50 rounded">
                            <Trash2 className="w-4 h-4 text-red-500" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                  <button
                    onClick={() => setEditingAddress({ id: '', user_id: '', type: 'shipping', is_default: false, full_name: '', phone: '', address_line1: '', city: '', state: '', postal_code: '', country: 'India', created_at: '' } as Address)}
                    className="border-2 border-dashed rounded-lg p-8 flex flex-col items-center justify-center text-gray-400 hover:text-primary hover:border-primary transition-colors"
                  >
                    <MapPin className="w-8 h-8 mb-2" />
                    Add New Address
                  </button>
                </div>
              </div>
            )}

            {/* Profile */}
            {activeTab === 'profile' && (
              <div className="bg-white rounded-xl p-6">
                <h2 className="font-heading font-semibold text-xl mb-6">Profile Settings</h2>
                <form onSubmit={handleUpdateProfile} className="space-y-4 max-w-md">
                  <div>
                    <label className="label">Full Name</label>
                    <input
                      type="text"
                      className="input"
                      value={profileForm.full_name}
                      onChange={(e) => setProfileForm({ ...profileForm, full_name: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="label">Phone Number</label>
                    <input
                      type="tel"
                      className="input"
                      value={profileForm.phone}
                      onChange={(e) => setProfileForm({ ...profileForm, phone: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="label">Email Address</label>
                    <input
                      type="email"
                      className="input bg-gray-50"
                      value={profile?.email || ''}
                      disabled
                    />
                    <p className="text-xs text-gray-500 mt-1">Email cannot be changed</p>
                  </div>
                  <button type="submit" className="btn-primary">Save Changes</button>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
