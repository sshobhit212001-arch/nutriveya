import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  CheckCircle,
  Leaf,
  Shield,
  Truck,
  Heart,
  Award,
  Clock,
  Package,
  Star,
  Quote,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useCart } from '../contexts/CartContext';
import type { Product, Category, Blog } from '../types/database';
import ProductCard from '../components/product/ProductCard';

const features = [
  { icon: Leaf, title: '100% Natural', description: 'Pure organic ingredients' },
  { icon: Shield, title: 'Lab Tested', description: 'Quality verified products' },
  { icon: Heart, title: 'No Chemicals', description: 'Chemical-free processing' },
  { icon: Truck, title: 'Fast Delivery', description: 'Pan-India shipping' },
  { icon: Package, title: 'Fresh Stock', description: 'Farm-fresh ingredients' },
  { icon: Award, title: 'Certified', description: 'FSSAI & GMP certified' },
  { icon: Clock, title: 'Secure Payment', description: '100% secure checkout' },
  { icon: CheckCircle, title: 'Satisfaction', description: 'Customer guarantee' },
];

const benefits = [
  {
    title: 'Boosts Immunity',
    description: 'Rich in antioxidants and essential vitamins that strengthen your natural defenses.',
    image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=400',
  },
  {
    title: 'Increases Energy',
    description: 'Natural ingredients provide sustained energy without caffeine crashes.',
    image: 'https://images.pexels.com/photos/1640774/pexels-photo-1640774.jpeg?auto=compress&cs=tinysrgb&w=400',
  },
  {
    title: 'Rich in Antioxidants',
    description: 'Powerful antioxidants protect cells from oxidative stress and aging.',
    image: 'https://images.pexels.com/photos/4199098/pexels-photo-4199098.jpeg?auto=compress&cs=tinysrgb&w=400',
  },
  {
    title: 'Improves Digestion',
    description: 'Natural fiber and enzymes support healthy digestive function.',
    image: 'https://images.pexels.com/photos/557659/pexels-photo-557659.jpeg?auto=compress&cs=tinysrgb&w=400',
  },
  {
    title: 'Promotes Healthy Skin',
    description: 'Vitamins and minerals nourish skin from within for a natural glow.',
    image: 'https://images.pexels.com/photos/3693891/pexels-photo-3693891.jpeg?auto=compress&cs=tinysrgb&w=400',
  },
  {
    title: 'Overall Wellness',
    description: 'Comprehensive nutrition support for holistic health and vitality.',
    image: 'https://images.pexels.com/photos/4226896/pexels-photo-4226896.jpeg?auto=compress&cs=tinysrgb&w=400',
  },
];

const testimonials = [
  {
    name: 'Priya Sharma',
    location: 'Mumbai',
    rating: 5,
    text: 'Nutriveya Moringa has become my daily ritual. I feel more energetic and my skin has never looked better. The quality is exceptional!',
    avatar: 'https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg?auto=compress&cs=tinysrgb&w=100',
  },
  {
    name: 'Rajesh Kumar',
    location: 'Delhi',
    rating: 5,
    text: 'Best Ashwagandha powder I have tried. Helps me manage stress and sleep better. Highly recommend for anyone looking for authentic organic products.',
    avatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=100',
  },
  {
    name: 'Anita Patel',
    location: 'Bangalore',
    rating: 5,
    text: 'The quality of Nutriveya products is outstanding. You can taste the purity. My whole family now uses their superfoods daily.',
    avatar: 'https://images.pexels.com/photos/3756679/pexels-photo-3756679.jpeg?auto=compress&cs=tinysrgb&w=100',
  },
  {
    name: 'Dr. Vikram Singh',
    location: 'Jaipur',
    rating: 5,
    text: 'As a nutritionist, I recommend Nutriveya to my patients. Their commitment to quality and purity is commendable.',
    avatar: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=100',
  },
];

const certifications = [
  { name: 'FSSAI', description: 'Food Safety' },
  { name: 'ISO', description: 'Quality Management' },
  { name: 'GMP', description: 'Good Manufacturing' },
  { name: 'HACCP', description: 'Food Safety System' },
  { name: 'Organic', description: 'Certified Organic' },
];

export default function HomePage() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [bestsellerProducts, setBestsellerProducts] = useState<Product[]>([]);
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const { addToCart } = useCart();

  useEffect(() => {
    async function fetchData() {
      try {
        const [categoriesRes, featuredRes, bestsellersRes, blogsRes] = await Promise.all([
          supabase.from('categories').select('*').eq('is_active', true).order('display_order').limit(10),
          supabase.from('products').select('*').eq('is_featured', true).eq('is_active', true).limit(4),
          supabase.from('products').select('*').eq('is_bestseller', true).eq('is_active', true).limit(8),
          supabase.from('blogs').select('*').eq('is_published', true).order('published_at', { ascending: false }).limit(3),
        ]);

        setCategories(categoriesRes.data || []);
        setFeaturedProducts(featuredRes.data || []);
        setBestsellerProducts(bestsellersRes.data || []);
        setBlogs(blogsRes.data || []);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary-900 via-primary-800 to-primary-700 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-20 w-64 h-64 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-gold rounded-full blur-3xl" />
        </div>
        <div className="container-custom relative py-20 md:py-32">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="inline-flex items-center gap-2 bg-white/10 rounded-full px-4 py-2 text-sm">
                <Leaf className="w-4 h-4" />
                <span>100% Organic & Natural</span>
              </div>
              <h1 className="font-heading font-bold text-4xl md:text-5xl lg:text-6xl leading-tight">
                Nature's Nutrition,
                <span className="text-gold"> Purely Delivered.</span>
              </h1>
              <p className="text-lg md:text-xl text-primary-100 max-w-xl">
                Premium organic superfood powders made with carefully selected natural ingredients
                to support your daily health and wellness journey.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/shop" className="btn-gold text-lg">
                  Shop Now
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Link>
                <Link to="/categories" className="btn bg-white/10 backdrop-blur-sm text-white hover:bg-white/20">
                  Explore Products
                </Link>
              </div>
              <div className="flex items-center gap-8 pt-4">
                <div className="text-center">
                  <p className="font-heading font-bold text-3xl text-gold">10K+</p>
                  <p className="text-sm text-primary-200">Happy Customers</p>
                </div>
                <div className="w-px h-12 bg-white/20" />
                <div className="text-center">
                  <p className="font-heading font-bold text-3xl text-gold">50+</p>
                  <p className="text-sm text-primary-200">Products</p>
                </div>
                <div className="w-px h-12 bg-white/20" />
                <div className="text-center">
                  <p className="font-heading font-bold text-3xl text-gold">4.9</p>
                  <p className="text-sm text-primary-200">Star Rating</p>
                </div>
              </div>
            </div>
            <div className="relative hidden lg:block">
              <div className="absolute inset-0 bg-gradient-to-br from-gold/20 to-primary/20 rounded-full blur-2xl" />
              <img
                src="https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Organic Superfoods"
                className="relative z-10 w-full max-w-lg mx-auto rounded-2xl shadow-2xl"
              />
              <div className="absolute -bottom-4 -left-4 bg-white rounded-xl p-4 shadow-lg z-20">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center">
                    <Shield className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <p className="font-heading font-semibold text-gray-900">Lab Tested</p>
                    <p className="text-sm text-gray-500">Quality Assured</p>
                  </div>
                </div>
              </div>
              <div className="absolute -top-4 -right-4 bg-white rounded-xl p-4 shadow-lg z-20">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gold-100 rounded-full flex items-center justify-center">
                    <Star className="w-6 h-6 text-gold fill-gold" />
                  </div>
                  <div>
                    <p className="font-heading font-semibold text-gray-900">Best Seller</p>
                    <p className="text-sm text-gray-500">Moringa Powder</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-white">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="section-title mb-4">Why Choose Nutriveya?</h2>
            <p className="section-subtitle">
              Our commitment to quality, purity, and your health sets us apart.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {features.map((feature) => (
              <div
                key={feature.title}
                className="text-center p-6 rounded-xl hover:bg-primary-50 transition-colors group"
              >
                <div className="w-16 h-16 mx-auto mb-4 bg-primary-100 rounded-full flex items-center justify-center group-hover:bg-primary group-hover:text-white transition-colors">
                  <feature.icon className="w-7 h-7 text-primary group-hover:text-white" />
                </div>
                <h3 className="font-heading font-semibold text-gray-900 mb-1">
                  {feature.title}
                </h3>
                <p className="text-sm text-gray-500">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-16 bg-cream">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="section-title mb-4">Featured Categories</h2>
            <p className="section-subtitle">
              Explore our range of premium organic superfoods.
            </p>
          </div>
          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {[...Array(10)].map((_, i) => (
                <div key={i} className="aspect-square bg-gray-200 rounded-xl animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {categories.map((category) => (
                <Link
                  key={category.id}
                  to={`/category/${category.slug}`}
                  className="group relative aspect-square rounded-xl overflow-hidden"
                >
                  <img
                    src={`https://images.pexels.com/photos/164077${7 + categories.indexOf(category) % 10}/pexels-photo-164077${7 + categories.indexOf(category) % 10}.jpeg?auto=compress&cs=tinysrgb&w=400`}
                    alt={category.name}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <h3 className="font-heading font-semibold text-white text-sm md:text-base">
                      {category.name}
                    </h3>
                    <span className="text-xs text-gray-300 flex items-center gap-1 mt-1 group-hover:text-gold transition-colors">
                      Shop Now <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          )}
          <div className="text-center mt-8">
            <Link to="/categories" className="btn-secondary">
              View All Categories
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-white">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="section-title mb-4">Featured Products</h2>
            <p className="section-subtitle">
              Handpicked selections for your wellness journey.
            </p>
          </div>
          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="aspect-square bg-gray-200 rounded-xl animate-pulse" />
              ))}
            </div>
          ) : featuredProducts.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {featuredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={() => addToCart(product)}
                />
              ))}
            </div>
          ) : (
            <p className="text-center text-gray-500">No featured products available.</p>
          )}
          <div className="text-center mt-8">
            <Link to="/shop" className="btn-primary">
              Shop All Products
              <ArrowRight className="w-4 h-4 ml-2" />
            </Link>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-16 bg-primary text-white">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="section-title text-white mb-4">Benefits of Organic Nutrition</h2>
            <p className="section-subtitle text-primary-100">
              Discover how natural superfoods can transform your health.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {benefits.map((benefit) => (
              <div
                key={benefit.title}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-6 hover:bg-white/20 transition-colors"
              >
                <div className="aspect-video rounded-lg overflow-hidden mb-4">
                  <img
                    src={benefit.image}
                    alt={benefit.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="font-heading font-semibold text-lg mb-2">{benefit.title}</h3>
                <p className="text-primary-100 text-sm">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Best Sellers */}
      <section className="py-16 bg-cream">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="section-title mb-4">Best Sellers</h2>
            <p className="section-subtitle">
              Our most loved products by customers just like you.
            </p>
          </div>
          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="aspect-square bg-gray-200 rounded-xl animate-pulse" />
              ))}
            </div>
          ) : bestsellerProducts.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {bestsellerProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={() => addToCart(product)}
                />
              ))}
            </div>
          ) : (
            <p className="text-center text-gray-500">No bestseller products available.</p>
          )}
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-white">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="section-title mb-4">What Our Customers Say</h2>
            <p className="section-subtitle">
              Real stories from real people who trust Nutriveya.
            </p>
          </div>
          <div className="relative max-w-4xl mx-auto">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 bg-primary-100 rounded-full flex items-center justify-center">
              <Quote className="w-8 h-8 text-primary" />
            </div>
            <div className="bg-gray-50 rounded-2xl p-8 md:p-12 pt-16 relative overflow-hidden">
              <div className="absolute top-4 right-4 flex items-center gap-1">
                {[...Array(testimonials[activeTestimonial].rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-gold text-gold" />
                ))}
              </div>
              <p className="text-lg md:text-xl text-gray-700 mb-8 leading-relaxed">
                {testimonials[activeTestimonial].text}
              </p>
              <div className="flex items-center gap-4">
                <img
                  src={testimonials[activeTestimonial].avatar}
                  alt={testimonials[activeTestimonial].name}
                  className="w-14 h-14 rounded-full object-cover"
                />
                <div>
                  <p className="font-heading font-semibold text-gray-900">
                    {testimonials[activeTestimonial].name}
                  </p>
                  <p className="text-sm text-gray-500">{testimonials[activeTestimonial].location}</p>
                </div>
              </div>
              <div className="flex justify-center gap-2 mt-8">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setActiveTestimonial(index)}
                    className={`w-2 h-2 rounded-full transition-all ${
                      index === activeTestimonial ? 'bg-primary w-6' : 'bg-gray-300'
                    }`}
                  />
                ))}
              </div>
            </div>
            <button
              onClick={() => setActiveTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length)}
              className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 w-10 h-10 bg-white rounded-full shadow-md flex items-center justify-center hover:bg-gray-50"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={() => setActiveTestimonial((prev) => (prev + 1) % testimonials.length)}
              className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 w-10 h-10 bg-white rounded-full shadow-md flex items-center justify-center hover:bg-gray-50"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </section>

      {/* Certifications */}
      <section className="py-12 bg-gray-50">
        <div className="container-custom">
          <div className="text-center mb-8">
            <h2 className="font-heading font-bold text-2xl text-gray-900">
              Quality Certifications
            </h2>
          </div>
          <div className="flex flex-wrap justify-center gap-6 md:gap-12">
            {certifications.map((cert) => (
              <div key={cert.name} className="text-center">
                <div className="w-16 h-16 mx-auto mb-2 bg-white rounded-xl shadow-sm flex items-center justify-center border border-gray-100">
                  <Shield className="w-8 h-8 text-primary" />
                </div>
                <p className="font-heading font-semibold text-gray-900">{cert.name}</p>
                <p className="text-xs text-gray-500">{cert.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Blog */}
      <section className="py-16 bg-white">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="section-title mb-4">Latest from Our Blog</h2>
            <p className="section-subtitle">
              Health tips, nutrition insights, and wellness inspiration.
            </p>
          </div>
          {loading ? (
            <div className="grid md:grid-cols-3 gap-8">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="aspect-video bg-gray-200 rounded-xl animate-pulse" />
              ))}
            </div>
          ) : blogs.length > 0 ? (
            <div className="grid md:grid-cols-3 gap-8">
              {blogs.map((blog) => (
                <Link
                  key={blog.id}
                  to={`/blog/${blog.slug}`}
                  className="card group"
                >
                  <div className="aspect-video overflow-hidden">
                    <img
                      src={blog.featured_image || 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=600'}
                      alt={blog.title}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                  </div>
                  <div className="p-6">
                    <span className="text-xs text-primary font-medium">{blog.category}</span>
                    <h3 className="font-heading font-semibold text-gray-900 mt-2 line-clamp-2 group-hover:text-primary transition-colors">
                      {blog.title}
                    </h3>
                    <p className="text-sm text-gray-500 mt-2 line-clamp-2">{blog.excerpt}</p>
                    <div className="flex items-center justify-between mt-4 text-xs text-gray-400">
                      <span>{blog.author_name}</span>
                      <span>{new Date(blog.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <p className="text-center text-gray-500">No blog posts available.</p>
          )}
          <div className="text-center mt-8">
            <Link to="/blog" className="btn-secondary">
              Read All Articles
            </Link>
          </div>
        </div>
      </section>

      {/* Instagram Gallery */}
      <section className="py-16 bg-cream">
        <div className="container-custom">
          <div className="text-center mb-8">
            <h2 className="section-title mb-2">Follow Us on Instagram</h2>
            <a
              href="https://instagram.com/nutriveya"
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary hover:underline"
            >
              @nutriveya
            </a>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {[1640777, 1640774, 4199098, 557659, 3693891, 4226896].map((photoId, i) => (
              <a
                key={i}
                href="https://instagram.com/nutriveya"
                target="_blank"
                rel="noopener noreferrer"
                className="aspect-square overflow-hidden rounded-lg group"
              >
                <img
                  src={`https://images.pexels.com/photos/${photoId}/pexels-photo-${photoId}.jpeg?auto=compress&cs=tinysrgb&w=400`}
                  alt="Instagram"
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
              </a>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
