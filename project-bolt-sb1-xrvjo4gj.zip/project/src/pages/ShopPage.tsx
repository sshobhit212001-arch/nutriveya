import { useEffect, useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Filter, Grid, List, ChevronDown, X, ArrowUpDown } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useCart } from '../contexts/CartContext';
import type { Product, Category } from '../types/database';
import ProductCard from '../components/product/ProductCard';
import { Breadcrumb } from '../components/ui/Breadcrumb';
import { PageLoader } from '../components/ui/LoadingSpinner';

const sortOptions = [
  { value: 'featured', label: 'Featured' },
  { value: 'newest', label: 'Newest First' },
  { value: 'price_asc', label: 'Price: Low to High' },
  { value: 'price_desc', label: 'Price: High to Low' },
  { value: 'name_asc', label: 'Name: A to Z' },
];

export default function ShopPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showFilters, setShowFilters] = useState(false);
  const { addToCart } = useCart();

  const selectedCategory = searchParams.get('category') || '';
  const searchQuery = searchParams.get('search') || '';
  const sortBy = searchParams.get('sort') || 'featured';
  const selectedTags = searchParams.get('tags')?.split(',').filter(Boolean) || [];

  useEffect(() => {
    async function fetchData() {
      setLoading(true);
      try {
        const [productsRes, categoriesRes] = await Promise.all([
          supabase.from('products').select('*').eq('is_active', true),
          supabase.from('categories').select('*').eq('is_active', true).order('display_order'),
        ]);

        setProducts(productsRes.data || []);
        setCategories(categoriesRes.data || []);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  const filteredProducts = useMemo(() => {
    let filtered = [...products];

    if (selectedCategory) {
      const cat = categories.find((c) => c.slug === selectedCategory);
      if (cat) {
        filtered = filtered.filter((p) => p.category_id === cat.id);
      }
    }

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (p) =>
          p.name.toLowerCase().includes(query) ||
          p.short_description?.toLowerCase().includes(query) ||
          p.ingredients?.toLowerCase().includes(query)
      );
    }

    if (selectedTags.includes('bestseller')) {
      filtered = filtered.filter((p) => p.is_bestseller);
    }
    if (selectedTags.includes('new')) {
      filtered = filtered.filter((p) => p.is_new);
    }
    if (selectedTags.includes('featured')) {
      filtered = filtered.filter((p) => p.is_featured);
    }

    switch (sortBy) {
      case 'newest':
        filtered.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        break;
      case 'price_asc':
        filtered.sort((a, b) => a.price - b.price);
        break;
      case 'price_desc':
        filtered.sort((a, b) => b.price - a.price);
        break;
      case 'name_asc':
        filtered.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'featured':
      default:
        filtered.sort((a, b) => {
          if (a.is_featured && !b.is_featured) return -1;
          if (!a.is_featured && b.is_featured) return 1;
          return 0;
        });
    }

    return filtered;
  }, [products, categories, selectedCategory, searchQuery, sortBy, selectedTags]);

  const updateFilter = (key: string, value: string | null) => {
    const newParams = new URLSearchParams(searchParams);
    if (value) {
      newParams.set(key, value);
    } else {
      newParams.delete(key);
    }
    setSearchParams(newParams);
  };

  const toggleTag = (tag: string) => {
    const newTags = selectedTags.includes(tag)
      ? selectedTags.filter((t) => t !== tag)
      : [...selectedTags, tag];
    const newParams = new URLSearchParams(searchParams);
    if (newTags.length > 0) {
      newParams.set('tags', newTags.join(','));
    } else {
      newParams.delete('tags');
    }
    setSearchParams(newParams);
  };

  const clearFilters = () => {
    setSearchParams({});
  };

  const hasActiveFilters = selectedCategory || searchQuery || selectedTags.length > 0;

  if (loading) return <PageLoader />;

  return (
    <div className="min-h-screen bg-cream">
      <div className="container-custom py-8">
        <Breadcrumb items={[{ label: 'Shop' }]} />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="font-heading font-bold text-3xl text-gray-900">
              {selectedCategory
                ? categories.find((c) => c.slug === selectedCategory)?.name || 'Shop'
                : 'Shop All Products'}
            </h1>
            <p className="text-gray-500 mt-1">
              {filteredProducts.length} products found
            </p>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="md:hidden flex items-center gap-2 px-4 py-2 bg-white rounded-lg border border-gray-200"
            >
              <Filter className="w-4 h-4" />
              Filters
              {hasActiveFilters && (
                <span className="w-2 h-2 bg-primary rounded-full" />
              )}
            </button>

            <div className="flex items-center gap-2">
              <select
                value={sortBy}
                onChange={(e) => updateFilter('sort', e.target.value)}
                className="appearance-none bg-white px-4 py-2 pr-10 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-primary"
              >
                {sortOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              <ChevronDown className="w-4 h-4 -ml-8 pointer-events-none" />

              <div className="hidden md:flex items-center gap-1 bg-white rounded-lg border border-gray-200 p-1">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 rounded ${viewMode === 'grid' ? 'bg-primary text-white' : 'text-gray-500'}`}
                >
                  <Grid className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2 rounded ${viewMode === 'list' ? 'bg-primary text-white' : 'text-gray-500'}`}
                >
                  <List className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {searchQuery && (
          <div className="mb-4 p-3 bg-primary-50 rounded-lg flex items-center justify-between">
            <span className="text-sm text-gray-700">
              Showing results for: <strong>{searchQuery}</strong>
            </span>
            <button
              onClick={() => updateFilter('search', null)}
              className="text-primary hover:underline text-sm"
            >
              Clear search
            </button>
          </div>
        )}

        <div className="flex gap-8">
          {/* Sidebar Filters - Desktop */}
          <aside className="hidden md:block w-64 flex-shrink-0">
            <div className="bg-white rounded-xl p-6 sticky top-24">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-heading font-semibold text-lg">Filters</h3>
                {hasActiveFilters && (
                  <button
                    onClick={clearFilters}
                    className="text-sm text-primary hover:underline"
                  >
                    Clear all
                  </button>
                )}
              </div>

              <div className="mb-6">
                <h4 className="font-medium text-gray-900 mb-3">Categories</h4>
                <ul className="space-y-2">
                  {categories.map((category) => (
                    <li key={category.id}>
                      <button
                        onClick={() => updateFilter('category', category.slug === selectedCategory ? null : category.slug)}
                        className={`flex items-center gap-2 text-sm w-full text-left ${
                          category.slug === selectedCategory ? 'text-primary font-medium' : 'text-gray-600 hover:text-primary'
                        }`}
                      >
                        <span className={`w-3 h-3 rounded border ${category.slug === selectedCategory ? 'bg-primary border-primary' : 'border-gray-300'}`} />
                        {category.name}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mb-6">
                <h4 className="font-medium text-gray-900 mb-3">Quick Filters</h4>
                <div className="flex flex-wrap gap-2">
                  {['bestseller', 'new', 'featured'].map((tag) => (
                    <button
                      key={tag}
                      onClick={() => toggleTag(tag)}
                      className={`px-3 py-1.5 text-xs rounded-full border transition-colors ${
                        selectedTags.includes(tag)
                          ? 'bg-primary text-white border-primary'
                          : 'bg-white text-gray-600 border-gray-200 hover:border-primary'
                      }`}
                    >
                      {tag.charAt(0).toUpperCase() + tag.slice(1)}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-medium text-gray-900 mb-3">Price Range</h4>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <span>Rs {Math.min(...filteredProducts.map((p) => p.price)).toFixed(0)}</span>
                  <span>-</span>
                  <span>Rs {Math.max(...filteredProducts.map((p) => p.price)).toFixed(0)}</span>
                </div>
              </div>
            </div>
          </aside>

          {/* Mobile Filters */}
          {showFilters && (
            <div className="fixed inset-0 z-50 md:hidden">
              <div className="absolute inset-0 bg-black/50" onClick={() => setShowFilters(false)} />
              <div className="absolute right-0 top-0 bottom-0 w-80 bg-white p-6 overflow-auto">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="font-heading font-semibold text-lg">Filters</h3>
                  <button onClick={() => setShowFilters(false)}>
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="mb-6">
                  <h4 className="font-medium text-gray-900 mb-3">Categories</h4>
                  <ul className="space-y-2">
                    {categories.map((category) => (
                      <li key={category.id}>
                        <button
                          onClick={() => {
                            updateFilter('category', category.slug === selectedCategory ? null : category.slug);
                            setShowFilters(false);
                          }}
                          className={`flex items-center gap-2 text-sm w-full text-left ${
                            category.slug === selectedCategory ? 'text-primary font-medium' : 'text-gray-600'
                          }`}
                        >
                          <span className={`w-3 h-3 rounded border ${category.slug === selectedCategory ? 'bg-primary border-primary' : 'border-gray-300'}`} />
                          {category.name}
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mb-6">
                  <h4 className="font-medium text-gray-900 mb-3">Quick Filters</h4>
                  <div className="flex flex-wrap gap-2">
                    {['bestseller', 'new', 'featured'].map((tag) => (
                      <button
                        key={tag}
                        onClick={() => toggleTag(tag)}
                        className={`px-3 py-1.5 text-xs rounded-full border ${
                          selectedTags.includes(tag)
                            ? 'bg-primary text-white border-primary'
                            : 'bg-white text-gray-600 border-gray-200'
                        }`}
                      >
                        {tag.charAt(0).toUpperCase() + tag.slice(1)}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => {
                    clearFilters();
                    setShowFilters(false);
                  }}
                  className="w-full btn-secondary"
                >
                  Clear All Filters
                </button>
              </div>
            </div>
          )}

          {/* Product Grid */}
          <div className="flex-1">
            {filteredProducts.length > 0 ? (
              <div
                className={
                  viewMode === 'grid'
                    ? 'grid grid-cols-2 lg:grid-cols-3 gap-6'
                    : 'space-y-4'
                }
              >
                {filteredProducts.map((product) =>
                  viewMode === 'grid' ? (
                    <ProductCard
                      key={product.id}
                      product={product}
                      onAddToCart={() => addToCart(product)}
                    />
                  ) : (
                    <div
                      key={product.id}
                      className="bg-white rounded-xl p-4 flex gap-4 shadow-card"
                    >
                      <img
                        src={product.primary_image || product.images?.[0]}
                        alt={product.name}
                        className="w-32 h-32 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <h3 className="font-heading font-semibold text-gray-900">{product.name}</h3>
                        <p className="text-sm text-gray-500 mt-1 line-clamp-2">
                          {product.short_description}
                        </p>
                        <div className="flex items-center gap-4 mt-2">
                          <span className="font-bold text-primary">Rs {product.price.toFixed(0)}</span>
                          {product.compare_at_price && (
                            <span className="text-sm text-gray-400 line-through">
                              Rs {product.compare_at_price.toFixed(0)}
                            </span>
                          )}
                        </div>
                        <button
                          onClick={() => addToCart(product)}
                          className="btn-primary btn-sm mt-3"
                        >
                          Add to Cart
                        </button>
                      </div>
                    </div>
                  )
                )}
              </div>
            ) : (
              <div className="text-center py-16 bg-white rounded-xl">
                <div className="w-20 h-20 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                  <Grid className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="font-heading font-semibold text-gray-900 mb-2">No products found</h3>
                <p className="text-gray-500 mb-6">Try adjusting your filters or search query.</p>
                <button onClick={clearFilters} className="btn-primary">
                  Clear Filters
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
