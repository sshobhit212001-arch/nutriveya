import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Calendar, User, ChevronRight } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Blog } from '../types/database';
import { PageLoader } from '../components/ui/LoadingSpinner';
import { Breadcrumb } from '../components/ui/Breadcrumb';

const blogCategories = ['All', 'Nutrition', 'Ayurveda', 'Fitness', 'Lifestyle'];

export function BlogListPage() {
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState('All');

  useEffect(() => {
    async function fetchBlogs() {
      setLoading(true);
      let query = supabase.from('blogs').select('*').eq('is_published', true).order('published_at', { ascending: false });
      if (activeCategory !== 'All') {
        query = query.eq('category', activeCategory);
      }
      const { data } = await query;
      setBlogs(data || []);
      setLoading(false);
    }
    fetchBlogs();
  }, [activeCategory]);

  return (
    <div className="min-h-screen bg-cream py-8">
      <div className="container-custom">
        <Breadcrumb items={[{ label: 'Blog' }]} />

        <div className="text-center mb-12">
          <h1 className="font-heading font-bold text-4xl text-gray-900 mb-4">
            Health & Wellness Blog
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Discover articles on nutrition, Ayurveda, fitness, and holistic wellness to support your health journey.
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {blogCategories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                activeCategory === cat
                  ? 'bg-primary text-white'
                  : 'bg-white text-gray-600 hover:bg-gray-100'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {loading ? (
          <PageLoader />
        ) : blogs.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl">
            <p className="text-gray-500">No articles found.</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogs.map((blog) => (
              <Link
                key={blog.id}
                to={`/blog/${blog.slug}`}
                className="card group"
              >
                <div className="aspect-video overflow-hidden">
                  <img
                    src={blog.featured_image || 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=600'}
                    alt={blog.title}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                </div>
                <div className="p-6">
                  <div className="flex items-center gap-4 text-xs text-gray-500 mb-3">
                    {blog.category && (
                      <span className="text-primary font-medium">{blog.category}</span>
                    )}
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {new Date(blog.published_at || blog.created_at).toLocaleDateString('en-IN', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric',
                      })}
                    </span>
                  </div>
                  <h2 className="font-heading font-semibold text-lg text-gray-900 mb-2 line-clamp-2 group-hover:text-primary transition-colors">
                    {blog.title}
                  </h2>
                  <p className="text-sm text-gray-600 line-clamp-2 mb-4">{blog.excerpt}</p>
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span className="flex items-center gap-1">
                      <User className="w-3 h-3" />
                      {blog.author_name}
                    </span>
                    <span className="flex items-center text-primary group-hover:underline">
                      Read More <ChevronRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export function BlogDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const [blog, setBlog] = useState<Blog | null>(null);
  const [related, setRelated] = useState<Blog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchBlog() {
      if (!slug) return;
      setLoading(true);
      const { data } = await supabase.from('blogs').select('*').eq('slug', slug).maybeSingle();
      setBlog(data);

      if (data?.category) {
        const { data: relatedData } = await supabase
          .from('blogs')
          .select('*')
          .eq('category', data.category)
          .neq('id', data.id)
          .eq('is_published', true)
          .limit(3);
        setRelated(relatedData || []);
      }
      setLoading(false);
    }
    fetchBlog();
  }, [slug]);

  if (loading) return <PageLoader />;
  if (!blog) {
    return (
      <div className="min-h-screen bg-cream flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-500 mb-4">Article not found</p>
          <Link to="/blog" className="btn-primary">Back to Blog</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cream py-8">
      <div className="container-custom">
        <Breadcrumb items={[{ label: 'Blog', href: '/blog' }, { label: blog.title }]} />

        <article className="max-w-4xl mx-auto">
          <header className="text-center mb-8">
            {blog.category && (
              <span className="text-primary font-medium">{blog.category}</span>
            )}
            <h1 className="font-heading font-bold text-3xl md:text-4xl text-gray-900 mt-2 mb-4">
              {blog.title}
            </h1>
            <div className="flex items-center justify-center gap-4 text-sm text-gray-500">
              <span className="flex items-center gap-1">
                <User className="w-4 h-4" />
                {blog.author_name}
              </span>
              <span className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                {new Date(blog.published_at || blog.created_at).toLocaleDateString('en-IN', {
                  day: 'numeric',
                  month: 'long',
                  year: 'numeric',
                })}
              </span>
            </div>
          </header>

          {blog.featured_image && (
            <img
              src={blog.featured_image}
              alt={blog.title}
              className="w-full aspect-video object-cover rounded-xl mb-8"
            />
          )}

          <div className="bg-white rounded-xl p-8">
            <div className="prose prose-lg max-w-none">
              <p className="text-lg text-gray-700 mb-6">{blog.excerpt}</p>
              <div className="text-gray-600 leading-relaxed whitespace-pre-line">
                {blog.content}
              </div>
            </div>

            {blog.tags && blog.tags.length > 0 && (
              <div className="mt-8 pt-6 border-t">
                <p className="text-sm text-gray-500 mb-2">Tags:</p>
                <div className="flex flex-wrap gap-2">
                  {blog.tags.map((tag) => (
                    <span key={tag} className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-sm">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </article>

        {related.length > 0 && (
          <div className="max-w-4xl mx-auto mt-12">
            <h2 className="font-heading font-semibold text-2xl text-gray-900 mb-6">Related Articles</h2>
            <div className="grid md:grid-cols-3 gap-6">
              {related.map((r) => (
                <Link key={r.id} to={`/blog/${r.slug}`} className="card">
                  <div className="aspect-video overflow-hidden">
                    <img
                      src={r.featured_image || 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=400'}
                      alt={r.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-4">
                    <h3 className="font-heading font-semibold text-gray-900 line-clamp-2">{r.title}</h3>
                    <p className="text-xs text-gray-500 mt-2">{r.author_name}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
