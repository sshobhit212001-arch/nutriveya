import { Link } from 'react-router-dom';
import { Award, Leaf, Shield, Users, CheckCircle, Target, Eye, Heart } from 'lucide-react';

const values = [
  { icon: Leaf, title: '100% Natural', description: 'Pure, organic ingredients with no artificial additives or preservatives.' },
  { icon: Award, title: 'Premium Quality', description: 'Rigorous quality testing ensures every product meets our high standards.' },
  { icon: Shield, title: 'Lab Tested', description: 'Every batch is tested for purity, potency, and safety.' },
  { icon: Users, title: 'Customer First', description: 'Your health and satisfaction are our top priorities.' },
  { icon: Heart, title: 'Sustainability', description: 'Eco-friendly packaging and sustainable sourcing practices.' },
  { icon: CheckCircle, title: 'Transparency', description: 'Complete honesty about ingredients, sourcing, and processes.' },
];

const certifications = [
  { name: 'FSSAI', description: 'Food Safety and Standards Authority of India' },
  { name: 'ISO 9001:2015', description: 'Quality Management System' },
  { name: 'GMP', description: 'Good Manufacturing Practices' },
  { name: 'HACCP', description: 'Hazard Analysis Critical Control Points' },
  { name: 'USDA Organic', description: 'United States Department of Agriculture Organic' },
];

const stats = [
  { value: '10,000+', label: 'Happy Customers' },
  { value: '50+', label: 'Products' },
  { value: '4.9', label: 'Average Rating' },
  { value: '100%', label: 'Natural Ingredients' },
];

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-cream">
      {/* Hero */}
      <section className="bg-primary text-white py-16 md:py-24">
        <div className="container-custom text-center">
          <h1 className="font-heading font-bold text-4xl md:text-5xl mb-4">
            Our Story
          </h1>
          <p className="text-primary-100 text-lg max-w-2xl mx-auto">
            Dedicated to bringing you the purest organic superfoods for a healthier life.
          </p>
        </div>
      </section>

      {/* Founder Story */}
      <section className="py-16 bg-white">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Shiva Upadhyay - Founder"
                className="rounded-2xl shadow-lg"
              />
            </div>
            <div>
              <span className="text-primary font-medium">FOUNDED IN 2024</span>
              <h2 className="font-heading font-bold text-3xl md:text-4xl text-gray-900 mt-2 mb-6">
                A Vision for Pure Nutrition
              </h2>
              <p className="text-gray-600 mb-4">
                Nutriveya was founded in 2024 by Shiva Upadhyay with a clear vision: to make premium-quality organic nutrition accessible to every household. Growing up in a family that valued traditional wellness practices, Shiva witnessed firsthand the power of natural superfoods.
              </p>
              <p className="text-gray-600 mb-4">
                After years of researching nutritional science and Ayurvedic traditions, and seeing the proliferation of synthetic supplements and adulterated products in the market, Shiva decided to create a brand that would stand for purity and authenticity.
              </p>
              <p className="text-gray-600">
                Every Nutriveya product is a promise - a promise of quality, purity, and the goodness of nature in its most authentic form.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-16 bg-cream">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white rounded-xl p-8">
              <div className="w-14 h-14 bg-primary-100 rounded-full flex items-center justify-center mb-4">
                <Target className="w-7 h-7 text-primary" />
              </div>
              <h3 className="font-heading font-bold text-2xl text-gray-900 mb-4">Our Mission</h3>
              <p className="text-gray-600">
                To provide pure, high-quality organic superfood products that support healthier lives while maintaining transparency, sustainability, and customer trust. We believe everyone deserves access to authentic, chemical-free nutrition.
              </p>
            </div>
            <div className="bg-white rounded-xl p-8">
              <div className="w-14 h-14 bg-gold-100 rounded-full flex items-center justify-center mb-4">
                <Eye className="w-7 h-7 text-gold" />
              </div>
              <h3 className="font-heading font-bold text-2xl text-gray-900 mb-4">Our Vision</h3>
              <p className="text-gray-600">
                To become one of India's most trusted organic nutrition brands and expand globally through innovative, high-quality wellness products. We envision a world where natural nutrition is the first choice for health-conscious individuals.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 bg-primary text-white">
        <div className="container-custom">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {stats.map((stat) => (
              <div key={stat.label}>
                <p className="font-heading font-bold text-4xl text-gold">{stat.value}</p>
                <p className="text-primary-100">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 bg-white">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="section-title mb-4">Our Values</h2>
            <p className="section-subtitle">
              The principles that guide everything we do.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {values.map((value) => (
              <div key={value.title} className="text-center p-6 rounded-xl bg-gray-50">
                <div className="w-16 h-16 mx-auto mb-4 bg-primary-100 rounded-full flex items-center justify-center">
                  <value.icon className="w-8 h-8 text-primary" />
                </div>
                <h3 className="font-heading font-semibold text-xl text-gray-900 mb-2">{value.title}</h3>
                <p className="text-gray-600">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Certifications */}
      <section id="certifications" className="py-16 bg-cream">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="section-title mb-4">Quality Certifications</h2>
            <p className="section-subtitle">
              Our commitment to quality is validated by these certifications.
            </p>
          </div>
          <div className="flex flex-wrap justify-center gap-6">
            {certifications.map((cert) => (
              <div key={cert.name} className="bg-white rounded-xl p-6 text-center shadow-soft">
                <div className="w-20 h-20 mx-auto mb-4 bg-primary-100 rounded-full flex items-center justify-center">
                  <Shield className="w-10 h-10 text-primary" />
                </div>
                <h3 className="font-heading font-semibold text-gray-900">{cert.name}</h3>
                <p className="text-sm text-gray-500 mt-1">{cert.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-primary text-white">
        <div className="container-custom text-center">
          <h2 className="font-heading font-bold text-3xl md:text-4xl mb-4">
            Ready to Start Your Wellness Journey?
          </h2>
          <p className="text-primary-100 max-w-xl mx-auto mb-8">
            Explore our range of premium organic superfoods and experience the difference of pure nutrition.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/shop" className="btn-gold">
              Shop Now
            </Link>
            <Link to="/contact" className="btn bg-white/10 backdrop-blur-sm text-white hover:bg-white/20">
              Contact Us
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
