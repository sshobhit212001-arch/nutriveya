export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export interface Database {
  public: {
    Tables: {
      categories: {
        Row: {
          id: string;
          name: string;
          slug: string;
          description: string | null;
          image_url: string | null;
          parent_id: string | null;
          display_order: number;
          is_active: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          slug: string;
          description?: string | null;
          image_url?: string | null;
          parent_id?: string | null;
          display_order?: number;
          is_active?: boolean;
        };
        Update: {
          id?: string;
          name?: string;
          slug?: string;
          description?: string | null;
          image_url?: string | null;
          parent_id?: string | null;
          display_order?: number;
          is_active?: boolean;
        };
      };
      products: {
        Row: {
          id: string;
          category_id: string | null;
          name: string;
          slug: string;
          sku: string | null;
          short_description: string | null;
          long_description: string | null;
          price: number;
          compare_at_price: number | null;
          cost_price: number | null;
          images: string[];
          primary_image: string | null;
          ingredients: string | null;
          nutrition_facts: Json | null;
          benefits: string[];
          directions: string | null;
          storage_instructions: string | null;
          shelf_life: string | null;
          country_of_origin: string;
          stock_quantity: number;
          low_stock_threshold: number;
          weight: number | null;
          weight_unit: string;
          is_featured: boolean;
          is_bestseller: boolean;
          is_new: boolean;
          is_active: boolean;
          meta_title: string | null;
          meta_description: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          category_id?: string | null;
          name: string;
          slug: string;
          sku?: string | null;
          short_description?: string | null;
          long_description?: string | null;
          price: number;
          compare_at_price?: number | null;
          cost_price?: number | null;
          images?: string[];
          primary_image?: string | null;
          ingredients?: string | null;
          nutrition_facts?: Json | null;
          benefits?: string[];
          directions?: string | null;
          storage_instructions?: string | null;
          shelf_life?: string | null;
          country_of_origin?: string;
          stock_quantity?: number;
          low_stock_threshold?: number;
          weight?: number | null;
          weight_unit?: string;
          is_featured?: boolean;
          is_bestseller?: boolean;
          is_new?: boolean;
          is_active?: boolean;
          meta_title?: string | null;
          meta_description?: string | null;
        };
        Update: {
          id?: string;
          category_id?: string | null;
          name?: string;
          slug?: string;
          sku?: string | null;
          short_description?: string | null;
          long_description?: string | null;
          price?: number;
          compare_at_price?: number | null;
          cost_price?: number | null;
          images?: string[];
          primary_image?: string | null;
          ingredients?: string | null;
          nutrition_facts?: Json | null;
          benefits?: string[];
          directions?: string | null;
          storage_instructions?: string | null;
          shelf_life?: string | null;
          country_of_origin?: string;
          stock_quantity?: number;
          low_stock_threshold?: number;
          weight?: number | null;
          weight_unit?: string;
          is_featured?: boolean;
          is_bestseller?: boolean;
          is_new?: boolean;
          is_active?: boolean;
          meta_title?: string | null;
          meta_description?: string | null;
        };
      };
      users: {
        Row: {
          id: string;
          email: string;
          full_name: string | null;
          phone: string | null;
          avatar_url: string | null;
          is_admin: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email: string;
          full_name?: string | null;
          phone?: string | null;
          avatar_url?: string | null;
          is_admin?: boolean;
        };
        Update: {
          email?: string;
          full_name?: string | null;
          phone?: string | null;
          avatar_url?: string | null;
          is_admin?: boolean;
        };
      };
      addresses: {
        Row: {
          id: string;
          user_id: string;
          type: string;
          is_default: boolean;
          full_name: string;
          phone: string;
          address_line1: string;
          address_line2: string | null;
          city: string;
          state: string;
          postal_code: string;
          country: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          type?: string;
          is_default?: boolean;
          full_name: string;
          phone: string;
          address_line1: string;
          address_line2?: string | null;
          city: string;
          state: string;
          postal_code: string;
          country?: string;
        };
        Update: {
          type?: string;
          is_default?: boolean;
          full_name?: string;
          phone?: string;
          address_line1?: string;
          address_line2?: string | null;
          city?: string;
          state?: string;
          postal_code?: string;
          country?: string;
        };
      };
      orders: {
        Row: {
          id: string;
          user_id: string;
          order_number: string;
          status: string;
          subtotal: number;
          shipping_cost: number;
          tax: number;
          discount: number;
          total: number;
          coupon_code: string | null;
          shipping_address: Json;
          billing_address: Json | null;
          payment_method: string | null;
          payment_status: string;
          payment_id: string | null;
          notes: string | null;
          shipped_at: string | null;
          delivered_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          order_number: string;
          status?: string;
          subtotal: number;
          shipping_cost?: number;
          tax?: number;
          discount?: number;
          total: number;
          coupon_code?: string | null;
          shipping_address: Json;
          billing_address?: Json | null;
          payment_method?: string | null;
          payment_status?: string;
          payment_id?: string | null;
          notes?: string | null;
        };
        Update: {
          status?: string;
          shipping_cost?: number;
          tax?: number;
          discount?: number;
          coupon_code?: string | null;
          billing_address?: Json | null;
          payment_method?: string | null;
          payment_status?: string;
          payment_id?: string | null;
          notes?: string | null;
          shipped_at?: string | null;
          delivered_at?: string | null;
        };
      };
      order_items: {
        Row: {
          id: string;
          order_id: string;
          product_id: string | null;
          product_name: string;
          product_sku: string | null;
          quantity: number;
          unit_price: number;
          total_price: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          order_id: string;
          product_id?: string | null;
          product_name: string;
          product_sku?: string | null;
          quantity: number;
          unit_price: number;
          total_price: number;
        };
      };
      cart_items: {
        Row: {
          id: string;
          user_id: string;
          product_id: string;
          quantity: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          product_id: string;
          quantity?: number;
        };
        Update: {
          quantity?: number;
        };
      };
      wishlist_items: {
        Row: {
          id: string;
          user_id: string;
          product_id: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          product_id: string;
        };
      };
      reviews: {
        Row: {
          id: string;
          user_id: string;
          product_id: string;
          rating: number;
          title: string | null;
          content: string | null;
          is_verified_purchase: boolean;
          is_approved: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          product_id: string;
          rating: number;
          title?: string | null;
          content?: string | null;
          is_verified_purchase?: boolean;
          is_approved?: boolean;
        };
      };
      blogs: {
        Row: {
          id: string;
          title: string;
          slug: string;
          excerpt: string | null;
          content: string | null;
          featured_image: string | null;
          category: string | null;
          tags: string[];
          author_name: string | null;
          is_published: boolean;
          published_at: string | null;
          meta_title: string | null;
          meta_description: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          title: string;
          slug: string;
          excerpt?: string | null;
          content?: string | null;
          featured_image?: string | null;
          category?: string | null;
          tags?: string[];
          author_name?: string | null;
          is_published?: boolean;
          published_at?: string | null;
          meta_title?: string | null;
          meta_description?: string | null;
        };
        Update: {
          title?: string;
          slug?: string;
          excerpt?: string | null;
          content?: string | null;
          featured_image?: string | null;
          category?: string | null;
          tags?: string[];
          author_name?: string | null;
          is_published?: boolean;
          published_at?: string | null;
          meta_title?: string | null;
          meta_description?: string | null;
        };
      };
      coupons: {
        Row: {
          id: string;
          code: string;
          type: 'percentage' | 'fixed';
          value: number;
          min_order_value: number | null;
          max_uses: number | null;
          used_count: number;
          valid_from: string | null;
          valid_until: string | null;
          is_active: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          code: string;
          type: 'percentage' | 'fixed';
          value: number;
          min_order_value?: number | null;
          max_uses?: number | null;
          used_count?: number;
          valid_from?: string | null;
          valid_until?: string | null;
          is_active?: boolean;
        };
      };
    };
  };
}

export type Category = Database['public']['Tables']['categories']['Row'];
export type Product = Database['public']['Tables']['products']['Row'];
export type User = Database['public']['Tables']['users']['Row'];
export type Address = Database['public']['Tables']['addresses']['Row'];
export type Order = Database['public']['Tables']['orders']['Row'];
export type OrderItem = Database['public']['Tables']['order_items']['Row'];
export type CartItem = Database['public']['Tables']['cart_items']['Row'];
export type WishlistItem = Database['public']['Tables']['wishlist_items']['Row'];
export type Review = Database['public']['Tables']['reviews']['Row'];
export type Blog = Database['public']['Tables']['blogs']['Row'];
export type Coupon = Database['public']['Tables']['coupons']['Row'];

export type ProductWithCategory = Product & { category: Category | null };
export type CartItemWithProduct = CartItem & { product: Product };
export type WishlistItemWithProduct = WishlistItem & { product: Product };
export type OrderWithItems = Order & { items: OrderItem[] };
export type ReviewWithUser = Review & { user: { full_name: string } | null };
