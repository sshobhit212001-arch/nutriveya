import { Link } from 'react-router-dom';
import { Heart, ShoppingCart, Star } from 'lucide-react';
import { useState } from 'react';
import type { Product } from '../../types/database';

interface ProductCardProps {
  product: Product;
  onAddToCart?: (product: Product) => void;
  onAddToWishlist?: (product: Product) => void;
}

export default function ProductCard({ product, onAddToCart, onAddToWishlist }: ProductCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const discount = product.compare_at_price
    ? Math.round(((product.compare_at_price - product.price) / product.compare_at_price) * 100)
    : 0;

  const imageUrl = product.primary_image || product.images?.[0] || 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=600';

  return (
    <div
      className="card group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Image */}
      <div className="relative aspect-square overflow-hidden bg-gray-100">
        <img
          src={imageUrl}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
        />

        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {discount > 0 && (
            <span className="bg-red-500 text-white text-xs font-medium px-2 py-1 rounded">
              -{discount}%
            </span>
          )}
          {product.is_new && (
            <span className="bg-primary text-white text-xs font-medium px-2 py-1 rounded">
              New
            </span>
          )}
          {product.is_bestseller && (
            <span className="bg-gold text-white text-xs font-medium px-2 py-1 rounded">
              Bestseller
            </span>
          )}
        </div>

        {/* Wishlist button */}
        <button
          onClick={(e) => {
            e.preventDefault();
            onAddToWishlist?.(product);
          }}
          className={`absolute top-3 right-3 w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center transition-all ${
            isHovered ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-2'
          } hover:bg-primary hover:text-white`}
        >
          <Heart className="w-5 h-5" />
        </button>

        {/* Quick add to cart */}
        <button
          onClick={(e) => {
            e.preventDefault();
            onAddToCart?.(product);
          }}
          className={`absolute bottom-3 left-3 right-3 btn-primary justify-center ${
            isHovered ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          } transition-all duration-200`}
        >
          <ShoppingCart className="w-4 h-4 mr-2" />
          Add to Cart
        </button>

        {/* Out of stock */}
        {product.stock_quantity === 0 && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
            <span className="bg-white text-gray-900 px-4 py-2 rounded font-medium">
              Out of Stock
            </span>
          </div>
        )}
      </div>

      {/* Details */}
      <Link to={`/product/${product.slug}`} className="block p-4">
        {/* Rating */}
        <div className="flex items-center gap-1 mb-2">
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              className="w-4 h-4 fill-gold text-gold"
            />
          ))}
          <span className="text-sm text-gray-500 ml-1">(24)</span>
        </div>

        {/* Name */}
        <h3 className="font-heading font-semibold text-gray-900 group-hover:text-primary transition-colors line-clamp-2 mb-2">
          {product.name}
        </h3>

        {/* Short description */}
        {product.short_description && (
          <p className="text-sm text-gray-500 line-clamp-2 mb-3">
            {product.short_description}
          </p>
        )}

        {/* Price */}
        <div className="flex items-center gap-2">
          <span className="font-heading font-bold text-lg text-primary">
            Rs {product.price.toFixed(0)}
          </span>
          {product.compare_at_price && (
            <span className="text-sm text-gray-400 line-through">
              Rs {product.compare_at_price.toFixed(0)}
            </span>
          )}
        </div>

        {/* Weight */}
        {product.weight && (
          <p className="text-xs text-gray-500 mt-1">
            {product.weight} {product.weight_unit}
          </p>
        )}
      </Link>
    </div>
  );
}
