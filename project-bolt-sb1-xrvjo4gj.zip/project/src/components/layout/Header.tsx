import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  Search,
  ShoppingCart,
  User,
  Menu,
  X,
  ChevronDown,
  Heart,
  LogIn,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useCart } from '../../contexts/CartContext';

const navigation = [
  { name: 'Home', href: '/' },
  { name: 'Shop', href: '/shop' },
  {
    name: 'Categories',
    href: '/categories',
    children: [
      { name: 'Moringa Powder', href: '/category/moringa-powder' },
      { name: 'Ashwagandha', href: '/category/ashwagandha-powder' },
      { name: 'Wheatgrass', href: '/category/wheatgrass-powder' },
      { name: 'Amla Powder', href: '/category/amla-powder' },
      { name: 'Spirulina', href: '/category/spirulina-powder' },
      { name: 'View All', href: '/categories' },
    ],
  },
  { name: 'About Us', href: '/about' },
  { name: 'Blog', href: '/blog' },
  { name: 'Contact', href: '/contact' },
];

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const { user, profile } = useAuth();
  const { itemCount } = useCart();
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMobileMenuOpen(false);
    setActiveDropdown(null);
  }, [location.pathname]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      window.location.href = `/shop?search=${encodeURIComponent(searchQuery)}`;
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled || isMobileMenuOpen
          ? 'bg-white shadow-md'
          : 'bg-white/95 backdrop-blur-sm'
      }`}
    >
      {/* Top bar */}
      <div className="bg-primary text-white text-sm py-2">
        <div className="container-custom">
          <div className="flex items-center justify-between">
            <p className="hidden sm:block">Free shipping on orders above Rs 499</p>
            <div className="flex items-center gap-4 text-xs sm:text-sm">
              <a href="tel:+919876543210" className="hover:text-gold transition-colors">
                +91 98765 43210
              </a>
              <span className="hidden sm:inline">|</span>
              <a href="mailto:care@nutriveya.com" className="hidden sm:inline hover:text-gold transition-colors">
                care@nutriveya.com
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Main header */}
      <div className="container-custom">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 md:w-12 md:h-12 bg-primary rounded-full flex items-center justify-center">
              <span className="text-white font-heading font-bold text-lg md:text-xl">N</span>
            </div>
            <div className="hidden sm:block">
              <span className="font-heading font-bold text-xl md:text-2xl text-primary">Nutriveya</span>
              <p className="text-[10px] text-gray-500 -mt-1 tracking-wider">ORGANIC SUPERFOODS</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-8">
            {navigation.map((item) => (
              <div
                key={item.name}
                className="relative"
                onMouseEnter={() => item.children && setActiveDropdown(item.name)}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                <Link
                  to={item.href}
                  className={`flex items-center gap-1 font-heading font-medium text-sm transition-colors ${
                    location.pathname === item.href
                      ? 'text-primary'
                      : 'text-gray-700 hover:text-primary'
                  }`}
                >
                  {item.name}
                  {item.children && <ChevronDown className="w-4 h-4" />}
                </Link>

                {item.children && activeDropdown === item.name && (
                  <div className="absolute top-full left-0 pt-4 pb-2">
                    <div className="bg-white rounded-lg shadow-lg py-2 min-w-[200px] border border-gray-100">
                      {item.children.map((child) => (
                        <Link
                          key={child.name}
                          to={child.href}
                          className="block px-4 py-2 text-sm text-gray-700 hover:bg-primary-50 hover:text-primary transition-colors"
                        >
                          {child.name}
                        </Link>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </nav>

          {/* Right side icons */}
          <div className="flex items-center gap-2 md:gap-4">
            {/* Search */}
            <div className="relative">
              <button
                onClick={() => setIsSearchOpen(!isSearchOpen)}
                className="p-2 text-gray-700 hover:text-primary transition-colors"
                aria-label="Search"
              >
                <Search className="w-5 h-5" />
              </button>

              {isSearchOpen && (
                <div className="absolute top-full right-0 mt-2 w-64 sm:w-80 bg-white rounded-lg shadow-lg border border-gray-100 p-4 animate-scale-in">
                  <form onSubmit={handleSearch}>
                    <input
                      type="text"
                      placeholder="Search products..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="input"
                      autoFocus
                    />
                  </form>
                </div>
              )}
            </div>

            {/* Wishlist */}
            <Link
              to="/wishlist"
              className="hidden sm:block p-2 text-gray-700 hover:text-primary transition-colors"
              aria-label="Wishlist"
            >
              <Heart className="w-5 h-5" />
            </Link>

            {/* Cart */}
            <Link
              to="/cart"
              className="relative p-2 text-gray-700 hover:text-primary transition-colors"
              aria-label="Cart"
            >
              <ShoppingCart className="w-5 h-5" />
              {itemCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-primary text-white text-xs rounded-full flex items-center justify-center font-medium">
                  {itemCount > 99 ? '99+' : itemCount}
                </span>
              )}
            </Link>

            {/* User */}
            {user ? (
              <Link
                to="/account"
                className="hidden sm:flex items-center gap-2 p-2 text-gray-700 hover:text-primary transition-colors"
              >
                <User className="w-5 h-5" />
                <span className="text-sm font-medium hidden lg:inline">
                  {profile?.full_name?.split(' ')[0] || 'Account'}
                </span>
              </Link>
            ) : (
              <Link
                to="/login"
                className="hidden sm:flex items-center gap-2 p-2 text-gray-700 hover:text-primary transition-colors"
              >
                <LogIn className="w-5 h-5" />
                <span className="text-sm font-medium hidden lg:inline">Login</span>
              </Link>
            )}

            {/* Mobile menu button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 text-gray-700"
              aria-label="Menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-white border-t border-gray-100 animate-slide-down">
          <div className="container-custom py-4">
            <form onSubmit={handleSearch} className="mb-4">
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="input"
              />
            </form>

            <nav className="space-y-2">
              {navigation.map((item) => (
                <div key={item.name}>
                  <Link
                    to={item.href}
                    className={`block px-4 py-2 rounded-lg font-medium ${
                      location.pathname === item.href
                        ? 'bg-primary-50 text-primary'
                        : 'text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    {item.name}
                  </Link>
                  {item.children && (
                    <div className="ml-4 mt-1 space-y-1">
                      {item.children.map((child) => (
                        <Link
                          key={child.name}
                          to={child.href}
                          className="block px-4 py-2 text-sm text-gray-600 hover:text-primary"
                        >
                          {child.name}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </nav>

            <div className="mt-4 pt-4 border-t border-gray-100">
              {user ? (
                <Link
                  to="/account"
                  className="flex items-center gap-2 px-4 py-2 text-gray-700"
                >
                  <User className="w-5 h-5" />
                  <span>My Account</span>
                </Link>
              ) : (
                <Link
                  to="/login"
                  className="flex items-center gap-2 px-4 py-2 text-gray-700"
                >
                  <LogIn className="w-5 h-5" />
                  <span>Login / Register</span>
                </Link>
              )}
              <Link
                to="/wishlist"
                className="flex items-center gap-2 px-4 py-2 text-gray-700"
              >
                <Heart className="w-5 h-5" />
                <span>Wishlist</span>
              </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
